import React, { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth'
import { supabase } from '../supabaseClient'

export const Sidebar = () => {
  const location = useLocation()
  const { role } = useAuth()
  const [showAddProject, setShowAddProject] = useState(false)
  const [newProjectTitle, setNewProjectTitle] = useState('')
  const [newProjectDesc, setNewProjectDesc] = useState('')

  const currentPath = location.pathname

  // Pages that should show the "+ New Project" button at the bottom of the sidebar
  const showNewProjectBtn = [
    '/contributions',
    '/contributions/new',
    '/events',
    '/progress',
    '/progress/admin',
    '/tasks'
  ].some(path => currentPath.startsWith(path)) || currentPath.includes('/events/') || currentPath.includes('/members/')

  // Reports link maps to progress for members, progress/admin for admins/coordinators
  const reportsPath = (role === 'admin' || role === 'coordinator') ? '/progress/admin' : '/progress'

  const handleCreateProject = async (e) => {
    e.preventDefault()
    if (!newProjectTitle.trim()) return

    try {
      const { error } = await supabase
        .from('projects')
        .insert({
          title: newProjectTitle,
          description: newProjectDesc,
          status: 'planned',
          progress: 0
        })

      if (error) throw error
      setNewProjectTitle('')
      setNewProjectDesc('')
      setShowAddProject(false)
      alert('Project created successfully!')
      // Refresh page or trigger hook reload if necessary
      window.location.reload()
    } catch (err) {
      console.error(err)
      alert('Error creating project: ' + err.message)
    }
  }

  const navItems = [
    { name: 'Dashboard', path: '/dashboard', icon: 'dashboard' },
    { name: 'Members', path: '/members', icon: 'group' },
    { name: 'Projects', path: '/projects', icon: 'account_tree' },
    { name: 'Teams', path: '/teams', icon: 'groups' },
    { name: 'Competitions', path: '/competitions', icon: 'emoji_events' },
    { name: 'Events', path: '/events', icon: 'event_available' },
    { name: 'Tasks', path: '/tasks', icon: 'assignment' },
    { 
      name: 'Admin Panel', 
      path: '/admin', 
      icon: 'admin_panel_settings', 
      isAdminOnly: true 
    },
    { name: 'Learn', path: '/learn', icon: 'school' },
    { name: 'Reports', path: reportsPath, icon: 'assessment' }
  ]

  return (
    <>
      <nav className="hidden md:flex flex-col bg-surface fixed left-0 top-0 h-screen w-sidebar-width border-r border-outline-variant py-stack-lg z-50">
        {/* Brand & Logo */}
        <div className="px-4 pt-2 mb-6">
          <img 
            alt="IOTHINC Logo" 
            className="block w-[120px] h-auto object-contain mx-auto" 
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuBxy40qeuMnls3d06xw0t5kGox9RUht3mkvxVfsRVQ9ldTgkrCudYy5N9CdhkzQbs-jPw8UuPENeSuX8oy3bVXhahrKbSTuYJcOlaDbPMSY3lAbO7CEIYGa_GeVeZJkmBIFh1btUx6ZB8TSPJbyoyGo1guSAn5Xjxx89sn6NTqKNTaPQdP1uBTPfI0F15QEZIvqfmavGM5uUexHIY2J2UqoQy9JgR6dnejoLavjUYTK1wXGk_6poaTxLm-6mQPkUFzteXmYha6p0_4"
          />
          <div className="mt-4 h-px w-full bg-outline-variant" />
        </div>

        {/* Navigation items */}
        <div className="flex-1 overflow-y-auto px-2 space-y-1 no-scrollbar">
          {navItems.map((item) => {
            const isRoleAdmin = role === 'admin'
            // If item is admin only and user is not admin, show locked status
            const isLocked = item.isAdminOnly && !isRoleAdmin
            const isActive = currentPath === item.path

            return (
              <Link
                key={item.name}
                to={isLocked ? '#' : item.path}
                onClick={(e) => {
                  if (isLocked) {
                    e.preventDefault()
                    alert('Access denied: Admin Panel is restricted to administrators.')
                  }
                }}
                className={`flex items-center gap-3 px-4 py-3 font-medium transition-all duration-150 rounded-full active:scale-[0.98] ${
                  isActive 
                    ? 'text-primary bg-primary-container/10 border-l-4 border-primary font-bold rounded-r-full' 
                    : 'text-on-surface-variant hover:bg-surface-container-high'
                }`}
              >
                <span className="material-symbols-outlined">{item.icon}</span>
                <span className="font-label-caps text-label-caps uppercase">{item.name}</span>
                {item.isAdminOnly && (
                  <span className="ml-auto material-symbols-outlined text-[16px] text-primary" title={isRoleAdmin ? "Admin Access Granted" : "Admin Only"}>
                    {isRoleAdmin ? 'lock_open' : 'lock'}
                  </span>
                )}
              </Link>
            )
          })}
        </div>

        {/* Dynamic bottom action items */}
        <div className="mt-auto px-4 pt-4 border-t border-outline-variant flex flex-col gap-3">
          {showNewProjectBtn && (
            <button 
              onClick={() => setShowAddProject(true)}
              className="w-full flex items-center justify-center gap-2 bg-primary text-on-primary font-label-caps text-label-caps uppercase py-3 rounded-lg hover:brightness-110 transition-all duration-150 active:scale-[0.98] shadow-sm font-bold"
            >
              <span className="material-symbols-outlined">add</span>
              New Project
            </button>
          )}

          <a className="flex items-center gap-3 px-4 py-3 text-on-surface-variant hover:bg-surface-container-high transition-colors duration-150 rounded-full active:scale-[0.98]" href="#docs">
            <span className="material-symbols-outlined">description</span>
            <span className="font-label-caps text-label-caps uppercase">Documentation</span>
          </a>
        </div>
      </nav>

      {/* Modal for creating a new project */}
      {showAddProject && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-surface border border-outline-variant rounded-xl max-w-md w-full p-6 shadow-xl animate-in fade-in zoom-in duration-200">
            <h3 className="font-headline-lg text-headline-lg text-on-surface mb-4">Create New Project</h3>
            <form onSubmit={handleCreateProject} className="space-y-4">
              <div>
                <label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Project Title</label>
                <input 
                  type="text" 
                  value={newProjectTitle}
                  onChange={(e) => setNewProjectTitle(e.target.value)}
                  className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant focus:ring-primary focus:border-primary text-sm"
                  placeholder="e.g. Club Website Redesign"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Description</label>
                <textarea 
                  value={newProjectDesc}
                  onChange={(e) => setNewProjectDesc(e.target.value)}
                  className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant focus:ring-primary focus:border-primary text-sm h-24 resize-none"
                  placeholder="Describe the project goal..."
                />
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button 
                  type="button"
                  onClick={() => setShowAddProject(false)}
                  className="px-4 py-2 text-on-surface-variant hover:bg-surface-container-high rounded-lg font-label-caps text-xs uppercase"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="px-5 py-2 bg-primary text-on-primary rounded-lg font-bold font-label-caps text-xs uppercase hover:brightness-110"
                >
                  Create
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  )
}

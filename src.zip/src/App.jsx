import React from 'react'
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom'
import { useAuth } from './hooks/useAuth'

/* Layout components */
import { Sidebar } from './components/Sidebar'
import { Navbar } from './components/Navbar'
import { ProtectedRoute } from './components/ProtectedRoute'

/* Pages */
import { Login } from './pages/Login'
import { Dashboard } from './pages/Dashboard'
import { Members } from './pages/Members'
import { MemberProfile } from './pages/MemberProfile'
import { Projects } from './pages/Projects'
import { ProjectDetail } from './pages/ProjectDetail'
import { Teams } from './pages/Teams'
import { CreateTeam } from './pages/CreateTeam'
import { Events } from './pages/Events'
import { EventDetail } from './pages/EventDetail'
import { Competitions } from './pages/Competitions'
import { CompetitionHost } from './pages/CompetitionHost'
import { Tasks } from './pages/Tasks'
import { Learn } from './pages/Learn'
import { NewResource } from './pages/NewResource'
import { Contributions } from './pages/Contributions'
import { NewContribution } from './pages/NewContribution'
import { ProgressTrackerMember } from './pages/ProgressTrackerMember'
import { ProgressTrackerAdmin } from './pages/ProgressTrackerAdmin'
import { AdminPanel } from './pages/AdminPanel'

/* Shell layout wrapping authenticated pages with sidebar + navbar */
const AppShell = ({ children }) => {
  return (
    <div className="min-h-screen bg-background flex">
      <Sidebar />
      <div className="flex-1 flex flex-col min-w-0">
        <Navbar />
        {children}
      </div>
    </div>
  )
}

/* Protect + wrap a page in the shell */
const Page = ({ children, allowedRoles }) => (
  <ProtectedRoute allowedRoles={allowedRoles}>
    <AppShell>{children}</AppShell>
  </ProtectedRoute>
)

function AppRoutes() {
  const { user, loading } = useAuth()
  const location = useLocation()

  // While auth is loading, show a minimal splash
  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <svg className="animate-spin h-10 w-10 text-primary" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
            <path className="opacity-75" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" fill="currentColor"/>
          </svg>
          <span className="text-on-surface-variant font-label-caps text-label-caps uppercase">Loading...</span>
        </div>
      </div>
    )
  }

  return (
    <Routes>
      {/* Public */}
      <Route path="/login" element={user ? <Navigate to="/dashboard" replace/> : <Login />} />

      {/* Authenticated routes */}
      <Route path="/dashboard" element={<Page><Dashboard /></Page>} />
      <Route path="/members" element={<Page><Members /></Page>} />
      <Route path="/members/:id" element={<Page><MemberProfile /></Page>} />
      <Route path="/projects" element={<Page><Projects /></Page>} />
      <Route path="/projects/:id" element={<Page><ProjectDetail /></Page>} />
      <Route path="/teams" element={<Page><Teams /></Page>} />
      <Route path="/teams/new" element={<Page allowedRoles={['admin','coordinator']}><CreateTeam /></Page>} />
      <Route path="/events" element={<Page><Events /></Page>} />
      <Route path="/events/:id" element={<Page><EventDetail /></Page>} />
      <Route path="/competitions" element={<Page><Competitions /></Page>} />
      <Route path="/competitions/host" element={<Page allowedRoles={['admin','coordinator']}><CompetitionHost /></Page>} />
      <Route path="/tasks" element={<Page><Tasks /></Page>} />
      <Route path="/learn" element={<Page><Learn /></Page>} />
      <Route path="/learn/new" element={<Page allowedRoles={['admin']}><NewResource /></Page>} />
      <Route path="/contributions" element={<Page><Contributions /></Page>} />
      <Route path="/contributions/new" element={<Page><NewContribution /></Page>} />
      <Route path="/progress" element={<Page><ProgressTrackerMember /></Page>} />
      <Route path="/progress/admin" element={<Page allowedRoles={['admin','coordinator']}><ProgressTrackerAdmin /></Page>} />
      <Route path="/admin" element={<Page allowedRoles={['admin']}><AdminPanel /></Page>} />

      {/* Fallback */}
      <Route path="*" element={<Navigate to={user ? "/dashboard" : "/login"} replace/>} />
    </Routes>
  )
}

function App() {
  return (
    <BrowserRouter>
      <AppRoutes />
    </BrowserRouter>
  )
}

export default App

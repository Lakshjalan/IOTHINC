import { useState, useEffect, useCallback } from 'react'
import { supabase } from '../supabaseClient'

export const useMembers = (filters = {}) => {
  const [members, setMembers] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const fetchMembers = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      let query = supabase
        .from('profiles')
        .select('*, contributions(count)')

      if (filters.department) {
        query = query.eq('department', filters.department)
      }
      if (filters.year) {
        query = query.eq('year', filters.year)
      }
      if (filters.role) {
        query = query.eq('role', filters.role)
      }

      const { data, error: fetchErr } = await query.order('full_name')

      if (fetchErr) throw fetchErr

      // Format response to flat contributions count
      const formatted = data.map(m => ({
        ...m,
        contributionsCount: m.contributions ? m.contributions[0]?.count || 0 : 0
      }))

      setMembers(formatted)
    } catch (err) {
      console.error(err)
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }, [filters.department, filters.year, filters.role])

  useEffect(() => {
    fetchMembers()
  }, [fetchMembers])

  const addMember = async (memberData) => {
    // Note: Creating user in auth is done via Supabase auth, this writes profile details
    // For admin to insert into profiles directly:
    const { data, error: err } = await supabase
      .from('profiles')
      .insert(memberData)
      .select()
      .single()

    if (err) throw err
    fetchMembers()
    return data
  }

  const updateMember = async (id, memberData) => {
    const { data, error: err } = await supabase
      .from('profiles')
      .update(memberData)
      .eq('id', id)
      .select()
      .single()

    if (err) throw err
    fetchMembers()
    return data
  }

  const deleteMember = async (id) => {
    const { error: err } = await supabase
      .from('profiles')
      .delete()
      .eq('id', id)

    if (err) throw err
    fetchMembers()
  }

  return {
    members,
    loading,
    error,
    refetch: fetchMembers,
    addMember,
    updateMember,
    deleteMember
  }
}

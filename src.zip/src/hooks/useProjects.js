import { useState, useEffect, useCallback } from 'react'
import { supabase } from '../supabaseClient'

export const useProjects = (filters = {}) => {
  const [projects, setProjects] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const fetchProjects = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      let query = supabase
        .from('projects')
        .select('*, teams(id, name)')

      if (filters.status) {
        query = query.eq('status', filters.status)
      }
      if (filters.category) {
        query = query.eq('category', filters.category)
      }

      const { data, error: fetchErr } = await query.order('created_at', { ascending: false })

      if (fetchErr) throw fetchErr
      setProjects(data || [])
    } catch (err) {
      console.error(err)
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }, [filters.status, filters.category])

  useEffect(() => {
    fetchProjects()
  }, [fetchProjects])

  const createProject = async (projectData) => {
    const { data, error: err } = await supabase
      .from('projects')
      .insert(projectData)
      .select()
      .single()

    if (err) throw err
    fetchProjects()
    return data
  }

  const updateProject = async (id, projectData) => {
    const { data, error: err } = await supabase
      .from('projects')
      .update(projectData)
      .eq('id', id)
      .select()
      .single()

    if (err) throw err
    fetchProjects()
    return data
  }

  const deleteProject = async (id) => {
    const { error: err } = await supabase
      .from('projects')
      .delete()
      .eq('id', id)

    if (err) throw err
    fetchProjects()
  }

  return {
    projects,
    loading,
    error,
    refetch: fetchProjects,
    createProject,
    updateProject,
    deleteProject
  }
}

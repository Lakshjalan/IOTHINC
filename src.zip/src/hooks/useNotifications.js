import { useState, useEffect, useCallback } from 'react'
import { supabase } from '../supabaseClient'
import { useAuth } from './useAuth'

export const useNotifications = () => {
  const { user, role } = useAuth()
  const [notifications, setNotifications] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const fetchNotifications = useCallback(async () => {
    if (!user) return
    setLoading(true)
    setError(null)
    try {
      const { data, error: fetchErr } = await supabase
        .from('notifications')
        .select(`
          *,
          sender:profiles!notifications_sender_id_fkey(full_name, avatar_url)
        `)
        .or(`target_member_id.eq.${user.id},target_role.eq.all,target_role.eq.${role || 'member'}`)
        .order('created_at', { ascending: false })

      if (fetchErr) throw fetchErr
      setNotifications(data || [])
    } catch (err) {
      console.error(err)
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }, [user, role])

  useEffect(() => {
    fetchNotifications()
  }, [fetchNotifications])

  const sendNotification = async (notifData) => {
    const { data, error: err } = await supabase
      .from('notifications')
      .insert({
        ...notifData,
        sender_id: user?.id
      })
      .select()
      .single()

    if (err) throw err
    fetchNotifications()
    return data
  }

  const markRead = async (id) => {
    const { error: err } = await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('id', id)

    if (err) throw err
    fetchNotifications()
  }

  return {
    notifications,
    loading,
    error,
    refetch: fetchNotifications,
    sendNotification,
    markRead
  }
}

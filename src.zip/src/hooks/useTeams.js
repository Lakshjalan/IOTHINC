import { useState, useEffect, useCallback } from 'react'
import { supabase } from '../supabaseClient'

export const useTeams = () => {
  const [teams, setTeams] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  const fetchTeams = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      // Fetch teams, leaders, member list, and projects count
      const { data, error: fetchErr } = await supabase
        .from('teams')
        .select(`
          *,
          lead:profiles!teams_lead_id_fkey(id, full_name, email, avatar_url),
          team_members(id, member_id, profiles(full_name)),
          projects(id)
        `)
        .order('name')

      if (fetchErr) throw fetchErr

      const formatted = (data || []).map(team => ({
        ...team,
        memberCount: team.team_members?.length || 0,
        projectCount: team.projects?.length || 0
      }))

      setTeams(formatted)
    } catch (err) {
      console.error(err)
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchTeams()
  }, [fetchTeams])

  const createTeam = async (name, department, leadId, memberIds) => {
    try {
      // 1. Insert into teams table
      const { data: team, error: teamErr } = await supabase
        .from('teams')
        .insert({ name, department, lead_id: leadId, status: 'active' })
        .select()
        .single()

      if (teamErr) throw teamErr

      // 2. Insert lead and other members into team_members table
      const uniqueMembers = Array.from(new Set([leadId, ...memberIds].filter(Boolean)))
      if (uniqueMembers.length > 0) {
        const memberRows = uniqueMembers.map(memberId => ({
          team_id: team.id,
          member_id: memberId
        }))

        const { error: memErr } = await supabase
          .from('team_members')
          .insert(memberRows)

        if (memErr) throw memErr
      }

      fetchTeams()
      return team
    } catch (err) {
      console.error('Error creating team:', err)
      throw err
    }
  }

  const deleteTeam = async (id) => {
    const { error: err } = await supabase
      .from('teams')
      .delete()
      .eq('id', id)

    if (err) throw err
    fetchTeams()
  }

  return {
    teams,
    loading,
    error,
    refetch: fetchTeams,
    createTeam,
    deleteTeam
  }
}

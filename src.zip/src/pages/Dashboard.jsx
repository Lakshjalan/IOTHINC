import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../supabaseClient'
import { useAuth } from '../hooks/useAuth'

export const Dashboard = () => {
  const { profile } = useAuth()

  // State Variables
  const [stats, setStats] = useState({
    activeProjects: 0,
    totalMembers: 0,
    upcomingEvents: 0,
    competitionDeadlines: 0
  })
  const [activeProjectsList, setActiveProjectsList] = useState([])
  const [upcomingEventsList, setUpcomingEventsList] = useState([])
  const [announcements, setAnnouncements] = useState([])
  const [loading, setLoading] = useState(true)

  // Title Setup
  useEffect(() => {
    document.title = "IOTHINC Management Hub"
  }, [])

  const fetchDashboardData = async () => {
    setLoading(true)
    try {
      const nowStr = new Date().toISOString()

      // 1. Fetch counts
      const [projCount, memCount, eventCount, compCount] = await Promise.all([
        supabase.from('projects').select('*', { count: 'exact', head: true }).eq('status', 'active'),
        supabase.from('profiles').select('*', { count: 'exact', head: true }),
        supabase.from('events').select('*', { count: 'exact', head: true }).gt('event_date', nowStr),
        supabase.from('competitions').select('*', { count: 'exact', head: true }).gt('registration_deadline', nowStr)
      ])

      setStats({
        activeProjects: projCount.count || 0,
        totalMembers: memCount.count || 0,
        upcomingEvents: eventCount.count || 0,
        competitionDeadlines: compCount.count || 0
      })

      // 2. Fetch Active Projects list
      const { data: projs } = await supabase
        .from('projects')
        .select('*')
        .eq('status', 'active')
        .order('created_at', { ascending: false })
        .limit(3)
      setActiveProjectsList(projs || [])

      // 3. Fetch Upcoming Events list
      const { data: evts } = await supabase
        .from('events')
        .select('*')
        .gt('event_date', nowStr)
        .order('event_date', { ascending: true })
        .limit(2)
      setUpcomingEventsList(evts || [])

      // 4. Fetch Announcements
      const { data: anns } = await supabase
        .from('notifications')
        .select(`
          *,
          sender:profiles!notifications_sender_id_fkey(full_name)
        `)
        .eq('type', 'announcement')
        .order('priority', { ascending: true })
        .order('created_at', { ascending: false })
        .limit(3)
      setAnnouncements(anns || [])

    } catch (err) {
      console.error('Error fetching dashboard data:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchDashboardData()

    // Real-time listener for dashboard updates
    const channel = supabase
      .channel('dashboard_updates')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'projects' }, () => fetchDashboardData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'profiles' }, () => fetchDashboardData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'events' }, () => fetchDashboardData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'notifications' }, () => fetchDashboardData())
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [])

  // Basic Calendar Math helper (Current Month: October 2024 as represented in static mock)
  const currentMonthYear = "October 2024"
  const calendarDays = [
    { day: 29, isCurrentMonth: false }, { day: 30, isCurrentMonth: false },
    { day: 1, isCurrentMonth: true }, { day: 2, isCurrentMonth: true },
    { day: 3, isCurrentMonth: true }, { day: 4, isCurrentMonth: true },
    { day: 5, isCurrentMonth: true }, { day: 6, isCurrentMonth: true },
    { day: 7, isCurrentMonth: true }, { day: 8, isCurrentMonth: true },
    { day: 9, isCurrentMonth: true }, { day: 10, isCurrentMonth: true },
    { day: 11, isCurrentMonth: true }, { day: 12, isCurrentMonth: true, isDeadline: true, tooltip: "Robotics Comp Reg" },
    { day: 13, isCurrentMonth: true }, { day: 14, isCurrentMonth: true },
    { day: 15, isCurrentMonth: true, isToday: true }, { day: 16, isCurrentMonth: true },
    { day: 17, isCurrentMonth: true }, { day: 18, isCurrentMonth: true },
    { day: 19, isCurrentMonth: true }, { day: 20, isCurrentMonth: true },
    { day: 21, isCurrentMonth: true }, { day: 22, isCurrentMonth: true },
    { day: 23, isCurrentMonth: true }, { day: 24, isCurrentMonth: true, isEvent: true, tooltip: "Tech Talk: AI" },
    { day: 25, isCurrentMonth: true }, { day: 26, isCurrentMonth: true },
    { day: 27, isCurrentMonth: true }, { day: 28, isCurrentMonth: true },
    { day: 29, isCurrentMonth: true }, { day: 30, isCurrentMonth: true },
    { day: 31, isCurrentMonth: true }, { day: 1, isCurrentMonth: false },
    { day: 2, isCurrentMonth: false }
  ]

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center min-h-[60vh]">
        <svg className="animate-spin h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path className="opacity-75" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" fill="currentColor"></path>
        </svg>
      </div>
    )
  }

  return (
    <main className="flex-1 px-4 md:px-stack-lg pt-24 pb-section-gap max-w-7xl mx-auto w-full animate-in fade-in duration-200">
      {/* Welcome Header */}
      <div className="mb-8">
        <h2 className="font-headline-xl text-headline-xl text-on-surface">
          Welcome back, {profile?.full_name || 'Member'}!
        </h2>
        <p className="font-body-md text-body-md text-on-surface-variant mt-2">
          Here is what's happening with IOTHINC today.
        </p>
      </div>

      {/* Stats Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {/* Active Projects */}
        <div className="bg-surface-container rounded-xl border border-outline-variant p-5 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-primary-container/10 rounded-lg text-primary">
              <span className="material-symbols-outlined fill-1">account_tree</span>
            </div>
            <span className="font-label-caps text-label-caps uppercase text-secondary bg-surface-container-high px-2 py-1 rounded-full">
              Live
            </span>
          </div>
          <div>
            <p className="font-label-caps text-label-caps uppercase text-on-surface-variant mb-1">Active Projects</p>
            <h3 className="font-headline-xl text-headline-xl text-on-surface">{stats.activeProjects}</h3>
          </div>
        </div>

        {/* Total Members */}
        <div className="bg-surface-container rounded-xl border border-outline-variant p-5 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-secondary-container rounded-lg text-on-secondary-container">
              <span className="material-symbols-outlined fill-1">group</span>
            </div>
            <span className="font-label-caps text-label-caps uppercase text-primary bg-primary-container/10 px-2 py-1 rounded-full">
              Members
            </span>
          </div>
          <div>
            <p className="font-label-caps text-label-caps uppercase text-on-surface-variant mb-1">Total Members</p>
            <h3 className="font-headline-xl text-headline-xl text-on-surface">{stats.totalMembers}</h3>
          </div>
        </div>

        {/* Upcoming Events */}
        <div className="bg-surface-container rounded-xl border border-outline-variant p-5 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-tertiary-fixed rounded-lg text-on-tertiary-fixed-variant">
              <span className="material-symbols-outlined fill-1">event</span>
            </div>
            <span className="font-label-caps text-label-caps uppercase text-success bg-success/10 px-2 py-1 rounded-full">
              New
            </span>
          </div>
          <div>
            <p className="font-label-caps text-label-caps uppercase text-on-surface-variant mb-1">Upcoming Events</p>
            <h3 className="font-headline-xl text-headline-xl text-on-surface">{stats.upcomingEvents}</h3>
          </div>
        </div>

        {/* Competition Deadlines */}
        <div className="bg-surface-container rounded-xl border border-outline-variant p-5 shadow-sm hover:shadow-md transition-shadow">
          <div className="flex justify-between items-start mb-4">
            <div className="p-2 bg-error-container rounded-lg text-on-error-container">
              <span className="material-symbols-outlined fill-1">timer</span>
            </div>
            <span className="font-label-caps text-label-caps uppercase text-error bg-error-container/30 px-2 py-1 rounded-full">
              Urgent
            </span>
          </div>
          <div>
            <p className="font-label-caps text-label-caps uppercase text-on-surface-variant mb-1">Competition Deadlines</p>
            <h3 className="font-headline-xl text-headline-xl text-on-surface">{stats.competitionDeadlines}</h3>
          </div>
        </div>
      </div>

      {/* Bento Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Active Projects Widget (8 cols) */}
        <div className="lg:col-span-8 bg-surface-container rounded-xl border border-outline-variant shadow-sm flex flex-col">
          <div className="p-5 border-b border-surface-variant flex justify-between items-center bg-surface-container-low rounded-t-xl">
            <h3 className="font-headline-lg text-headline-lg text-on-surface">Active Projects</h3>
            <Link to="/projects" className="text-primary font-label-caps text-label-caps uppercase hover:bg-primary-container/10 px-3 py-1.5 rounded-full transition-colors">
              View All
            </Link>
          </div>
          <div className="p-5 flex-1 flex flex-col gap-5">
            {activeProjectsList.length === 0 ? (
              <p className="text-sm text-on-surface-variant italic p-4 text-center">No active projects logged yet.</p>
            ) : (
              activeProjectsList.map((project) => (
                <div key={project.id} className="group">
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded bg-surface-container-high flex items-center justify-center text-secondary group-hover:bg-primary-container/10 group-hover:text-primary transition-colors">
                        <span className="material-symbols-outlined text-sm">code</span>
                      </div>
                      <span className="font-body-sm text-body-sm font-semibold text-on-surface">
                        {project.title}
                      </span>
                    </div>
                    <span className="font-label-caps text-label-caps uppercase text-on-surface-variant">
                      {project.progress}%
                    </span>
                  </div>
                  <div className="w-full bg-surface-container-highest rounded-full h-2">
                    <div className="bg-primary h-2 rounded-full transition-all duration-300" style={{ width: `${project.progress}%` }}></div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Upcoming Events Widget (4 cols) */}
        <div className="lg:col-span-4 bg-surface-container rounded-xl border border-outline-variant shadow-sm flex flex-col">
          <div className="p-5 border-b border-surface-variant bg-surface-container-low rounded-t-xl">
            <h3 className="font-headline-lg text-headline-lg text-on-surface">Upcoming Events</h3>
          </div>
          <div className="p-0 flex-1 divide-y divide-outline-variant">
            {upcomingEventsList.length === 0 ? (
              <p className="text-sm text-on-surface-variant italic p-6 text-center">No upcoming events scheduled.</p>
            ) : (
              upcomingEventsList.map((event) => {
                const eventDate = new Date(event.event_date)
                const month = eventDate.toLocaleString('default', { month: 'short' }).toUpperCase()
                const day = eventDate.getDate()
                const time = eventDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })

                return (
                  <Link to={`/events/${event.id}`} key={event.id} className="p-4 hover:bg-surface-container-low transition-colors flex gap-4 items-center">
                    <div className="flex flex-col items-center justify-center min-w-[48px] bg-surface-container-high rounded-lg p-2 border border-outline-variant">
                      <span className="font-label-caps text-label-caps uppercase text-primary font-bold">{month}</span>
                      <span className="font-headline-lg text-headline-lg text-on-surface leading-none">{day}</span>
                    </div>
                    <div>
                      <h4 className="font-body-sm text-body-sm font-bold text-on-surface">{event.title}</h4>
                      <p className="font-label-caps text-label-caps uppercase text-on-surface-variant mt-1 flex items-center gap-1">
                        <span className="material-symbols-outlined text-[14px]">schedule</span> {time} - {event.venue}
                      </p>
                    </div>
                  </Link>
                )
              })
            )}
          </div>
        </div>

        {/* Announcements (6 cols) */}
        <div className="lg:col-span-6 bg-surface-container rounded-xl border border-outline-variant shadow-sm flex flex-col">
          <div className="p-5 border-b border-surface-variant bg-surface-container-low rounded-t-xl">
            <h3 className="font-headline-lg text-headline-lg text-on-surface">Announcements</h3>
          </div>
          <div className="p-5 space-y-4">
            {announcements.length === 0 ? (
              <p className="text-sm text-on-surface-variant italic p-4 text-center">No system announcements.</p>
            ) : (
              announcements.map((ann) => (
                <div key={ann.id} className="flex gap-4">
                  <div className={`w-2 h-2 mt-2 rounded-full shrink-0 ${ann.priority === 1 ? 'bg-red-500' : ann.priority === 2 ? 'bg-amber-400' : 'bg-primary'}`}></div>
                  <div>
                    <h4 className="font-body-sm text-body-sm font-semibold text-on-surface">{ann.message}</h4>
                    <span className="font-label-caps text-label-caps uppercase text-outline mt-2 block">
                      By {ann.sender?.full_name || 'System'} • {new Date(ann.created_at).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Calendar / Deadlines (6 cols) */}
        <div className="lg:col-span-6 bg-surface-container rounded-xl border border-outline-variant shadow-sm flex flex-col p-5">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-headline-lg text-headline-lg text-on-surface">{currentMonthYear}</h3>
            <div className="flex gap-2">
              <button className="p-1 text-on-surface-variant hover:bg-surface-container-high rounded"><span className="material-symbols-outlined text-sm">chevron_left</span></button>
              <button className="p-1 text-on-surface-variant hover:bg-surface-container-high rounded"><span className="material-symbols-outlined text-sm">chevron_right</span></button>
            </div>
          </div>
          <div className="bg-surface-container-lowest rounded-lg border border-outline-variant p-4">
            <div className="grid grid-cols-7 gap-1 text-center mb-2 font-label-caps text-label-caps uppercase text-on-surface-variant">
              <div>S</div><div>M</div><div>T</div><div>W</div><div>T</div><div>F</div><div>S</div>
            </div>
            <div className="grid grid-cols-7 gap-1 text-center font-body-sm text-body-sm">
              {calendarDays.map((dayObj, index) => {
                let cellClass = "p-1 rounded transition-colors "
                if (!dayObj.isCurrentMonth) cellClass += "text-outline/40"
                else if (dayObj.isToday) cellClass += "bg-primary text-on-primary font-bold"
                else if (dayObj.isDeadline) cellClass += "bg-error-container text-on-error-container font-bold relative group cursor-pointer"
                else if (dayObj.isEvent) cellClass += "bg-tertiary-container text-on-tertiary-container font-bold relative group cursor-pointer"

                return (
                  <div key={index} className={cellClass}>
                    {dayObj.day}
                    {dayObj.tooltip && (
                      <span className="absolute hidden group-hover:block bottom-full mb-1 left-1/2 -translate-x-1/2 w-max p-1 bg-inverse-surface text-inverse-on-surface text-xs rounded z-10">
                        {dayObj.tooltip}
                      </span>
                    )}
                  </div>
                )
              })}
            </div>
          </div>
          <div className="mt-4 flex gap-4 font-label-caps text-label-caps uppercase text-xs">
            <div className="flex items-center gap-1"><div className="w-2.5 h-2.5 rounded bg-primary"></div> Today</div>
            <div className="flex items-center gap-1"><div className="w-2.5 h-2.5 rounded bg-error-container"></div> Deadline</div>
            <div className="flex items-center gap-1"><div className="w-2.5 h-2.5 rounded bg-tertiary-container"></div> Event</div>
          </div>
        </div>
      </div>
    </main>
  )
}

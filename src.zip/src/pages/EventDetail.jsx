import React, { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { supabase } from '../supabaseClient'
import { useAuth } from '../hooks/useAuth'
import { useEvents } from '../hooks/useEvents'

export const EventDetail = () => {
  const { id } = useParams()
  const { user, role } = useAuth()
  const { registerToEvent, cancelRegistration } = useEvents()
  const canManage = role === 'admin' || role === 'coordinator'

  const [event, setEvent] = useState(null)
  const [loading, setLoading] = useState(true)
  const [myReg, setMyReg] = useState(null)
  const [registrations, setRegistrations] = useState([])
  const [myTasks, setMyTasks] = useState([])

  const fetchEvent = async () => {
    setLoading(true)
    const { data: ev } = await supabase.from('events').select('*, organiser:profiles!events_created_by_fkey(id,full_name,avatar_url,department)').eq('id', id).single()
    setEvent(ev)
    document.title = `${ev?.title || 'Event'} | IOTHINC`

    if (user) {
      const { data: reg } = await supabase.from('event_registrations').select('*').eq('event_id', id).eq('user_id', user.id).maybeSingle()
      setMyReg(reg)

      const { data: tasks } = await supabase.from('tasks').select('*').eq('event_id', id).eq('assigned_to', user.id)
      setMyTasks(tasks || [])

      if (canManage) {
        const { data: allRegs } = await supabase.from('event_registrations').select('*, profile:profiles(full_name,avatar_url,department)').eq('event_id', id)
        setRegistrations(allRegs || [])
      }
    }
    setLoading(false)
  }

  useEffect(() => { fetchEvent() }, [id, user])

  const handleRegister = async () => {
    try { await registerToEvent(id); fetchEvent() } catch (err) { alert(err.message) }
  }
  const handleCancel = async () => {
    try { await cancelRegistration(id); fetchEvent() } catch (err) { alert(err.message) }
  }

  if (loading) return <main className="flex-1 px-4 md:px-stack-lg pt-24 pb-section-gap max-w-7xl mx-auto w-full"><div className="p-12 text-center"><svg className="animate-spin h-8 w-8 text-primary mx-auto" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" fill="currentColor"/></svg></div></main>
  if (!event) return <main className="flex-1 px-4 md:px-stack-lg pt-24 pb-section-gap max-w-7xl mx-auto w-full"><div className="text-center text-on-surface-variant text-lg mt-20">Event not found.</div></main>

  const d = new Date(event.event_date)

  return (
    <main className="flex-1 px-4 md:px-stack-lg pt-24 pb-section-gap max-w-7xl mx-auto w-full">
      <Link to="/events" className="inline-flex items-center gap-1.5 text-primary text-sm hover:underline mb-6">
        <span className="material-symbols-outlined text-lg">arrow_back</span>Back to Events
      </Link>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Main Info */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-surface-container rounded-xl border border-outline-variant p-6 shadow-sm">
            <div className="flex flex-wrap gap-2 mb-3">
              <span className="text-[10px] font-bold font-label-caps uppercase text-primary bg-primary-container/10 px-2 py-0.5 rounded">{event.category}</span>
              <span className={`text-[10px] font-bold font-label-caps uppercase px-2 py-0.5 rounded ${event.status === 'upcoming' ? 'bg-success/20 text-success' : event.status === 'ongoing' ? 'bg-primary/20 text-primary' : 'bg-surface-variant text-on-surface-variant'}`}>{event.status}</span>
            </div>
            <h1 className="font-headline-xl text-headline-xl text-on-surface mb-3">{event.title}</h1>
            <p className="text-sm text-on-surface-variant leading-relaxed whitespace-pre-line mb-6">{event.description}</p>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="flex items-center gap-2 text-on-surface-variant"><span className="material-symbols-outlined text-lg">schedule</span><div><div className="text-[10px] uppercase font-label-caps text-outline">Date & Time</div><div className="text-on-surface">{d.toLocaleDateString('en-US', {weekday:'long',year:'numeric',month:'long',day:'numeric'})} at {d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</div></div></div>
              <div className="flex items-center gap-2 text-on-surface-variant"><span className="material-symbols-outlined text-lg">location_on</span><div><div className="text-[10px] uppercase font-label-caps text-outline">Venue</div><div className="text-on-surface">{event.venue || 'TBD'}</div></div></div>
              {event.registration_deadline && <div className="flex items-center gap-2 text-on-surface-variant"><span className="material-symbols-outlined text-lg">timer</span><div><div className="text-[10px] uppercase font-label-caps text-outline">Reg. Deadline</div><div className="text-on-surface">{new Date(event.registration_deadline).toLocaleDateString()}</div></div></div>}
              <div className="flex items-center gap-2 text-on-surface-variant"><span className="material-symbols-outlined text-lg">event_seat</span><div><div className="text-[10px] uppercase font-label-caps text-outline">Max Seats</div><div className="text-on-surface">{event.max_seats || 'Unlimited'}</div></div></div>
            </div>
          </div>

          {/* Organiser */}
          {event.organiser && (
            <div className="bg-surface-container rounded-xl border border-outline-variant p-5 shadow-sm">
              <h3 className="font-headline-lg text-headline-lg text-on-surface mb-3">Organiser</h3>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary-container/20 flex items-center justify-center text-primary text-sm font-bold">{event.organiser.full_name?.charAt(0)?.toUpperCase()}</div>
                <div><div className="text-sm font-bold text-on-surface">{event.organiser.full_name}</div><div className="text-xs text-on-surface-variant">{event.organiser.department}</div></div>
              </div>
            </div>
          )}

          {/* My Tasks */}
          {myTasks.length > 0 && (
            <div className="bg-surface-container rounded-xl border border-outline-variant p-5 shadow-sm">
              <h3 className="font-headline-lg text-headline-lg text-on-surface mb-3">My Tasks for This Event</h3>
              <div className="space-y-3">
                {myTasks.map(t => (
                  <div key={t.id} className="bg-surface-container-low rounded-lg border border-outline-variant/50 p-4 flex items-center justify-between">
                    <div><div className="text-sm font-bold text-on-surface">{t.title}</div><div className="text-[10px] uppercase font-label-caps text-outline mt-1">{t.status} • {t.priority} priority</div></div>
                    <div className="text-right"><div className="text-sm font-mono-data text-primary">{t.progress ?? 0}%</div><div className="w-20 h-1.5 bg-surface rounded-full mt-1"><div className="h-full bg-primary rounded-full" style={{ width: `${t.progress ?? 0}%` }}/></div></div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <div className="bg-surface-container rounded-xl border border-outline-variant p-5 shadow-sm">
            <h3 className="font-headline-lg text-headline-lg text-on-surface mb-4">Registration</h3>
            {myReg ? (
              <div>
                <div className="flex items-center gap-2 text-success text-sm font-bold mb-3"><span className="material-symbols-outlined text-lg">check_circle</span>You are registered</div>
                <div className="text-xs text-on-surface-variant mb-4">Registered on {new Date(myReg.registered_at).toLocaleDateString()}</div>
                <button onClick={handleCancel} className="w-full py-2.5 rounded-lg border border-error/30 text-error text-xs font-bold font-label-caps uppercase hover:bg-error/10 transition-all">Cancel Registration</button>
              </div>
            ) : (
              <button onClick={handleRegister} className="w-full py-3 bg-primary text-on-primary font-bold font-label-caps text-xs uppercase rounded-lg hover:brightness-110 active:scale-[0.98] transition-all">Register Now</button>
            )}
          </div>

          {/* Admin Registrations */}
          {canManage && registrations.length > 0 && (
            <div className="bg-surface-container rounded-xl border border-outline-variant p-5 shadow-sm">
              <h3 className="text-sm font-bold text-on-surface mb-3">All Registrations ({registrations.length})</h3>
              <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
                {registrations.map(r => (
                  <div key={r.id} className="flex items-center gap-2 text-xs">
                    <div className="w-6 h-6 rounded-full bg-primary-container/20 flex items-center justify-center text-primary text-[10px] font-bold">{r.profile?.full_name?.charAt(0)?.toUpperCase()}</div>
                    <div><div className="text-on-surface">{r.profile?.full_name}</div><div className="text-[10px] text-outline">{r.profile?.department}</div></div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </main>
  )
}

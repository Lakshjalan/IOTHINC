import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useEvents } from '../hooks/useEvents'
import { useAuth } from '../hooks/useAuth'

export const Events = () => {
  const { role, user } = useAuth()
  const canManage = role === 'admin' || role === 'coordinator'
  const [statusTab, setStatusTab] = useState('All')
  const { events, loading, registerToEvent, toggleNotify, createEvent } = useEvents(statusTab)

  const [showCreate, setShowCreate] = useState(false)
  const [form, setForm] = useState({ title: '', description: '', category: 'WORKSHOP', venue: '', event_date: '', registration_deadline: '', max_seats: '' })

  useEffect(() => { document.title = "Events | IOTHINC" }, [])

  const handleCreate = async (e) => {
    e.preventDefault()
    try {
      await createEvent({ ...form, max_seats: form.max_seats ? parseInt(form.max_seats) : null, event_date: new Date(form.event_date).toISOString(), registration_deadline: form.registration_deadline ? new Date(form.registration_deadline).toISOString() : null })
      setShowCreate(false)
      setForm({ title: '', description: '', category: 'WORKSHOP', venue: '', event_date: '', registration_deadline: '', max_seats: '' })
    } catch (err) { alert('Error: ' + err.message) }
  }

  const handleRegister = async (id) => {
    try { await registerToEvent(id) } catch (err) { alert('Error: ' + err.message) }
  }

  const tabs = ['All', 'Upcoming', 'Ongoing', 'Past', 'My Events']

  return (
    <main className="flex-1 px-4 md:px-stack-lg pt-24 pb-section-gap max-w-7xl mx-auto w-full">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="font-headline-xl text-headline-xl text-on-surface">Events</h2>
          <p className="font-body-md text-body-md text-on-surface-variant mt-2">Discover, register, and stay updated on club activities.</p>
        </div>
        {canManage && (
          <button onClick={() => setShowCreate(true)} className="flex items-center gap-2 bg-primary text-on-primary font-bold font-label-caps text-xs uppercase px-4 py-3 rounded-lg hover:brightness-110 active:scale-[0.98] transition-all">
            <span className="material-symbols-outlined">add</span>Create Event
          </button>
        )}
      </div>

      <div className="flex gap-2 border-b border-outline-variant mb-6 pb-px overflow-x-auto no-scrollbar">
        {tabs.map(t => (
          <button key={t} onClick={() => setStatusTab(t)} className={`px-4 py-2.5 font-label-caps text-xs uppercase font-bold border-b-2 transition-all whitespace-nowrap ${statusTab === t ? 'border-primary text-primary' : 'border-transparent text-on-surface-variant hover:text-on-surface'}`}>{t}</button>
        ))}
      </div>

      {loading ? (
        <div className="p-12 text-center"><svg className="animate-spin h-8 w-8 text-primary mx-auto" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" fill="currentColor"/></svg></div>
      ) : events.length === 0 ? (
        <div className="bg-surface-container rounded-xl border border-outline-variant p-12 text-center text-on-surface-variant italic">No events found for this filter.</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {events.map(ev => {
            const d = new Date(ev.event_date)
            return (
              <div key={ev.id} className="bg-surface-container rounded-xl border border-outline-variant p-5 flex flex-col shadow-sm hover:shadow-md transition-shadow">
                <div className="flex justify-between items-start mb-3">
                  <span className="text-[10px] font-bold font-label-caps uppercase text-primary bg-primary-container/10 px-2 py-0.5 rounded">{ev.category}</span>
                  <span className={`text-[10px] font-bold font-label-caps uppercase px-2 py-0.5 rounded ${ev.status === 'upcoming' ? 'bg-success/20 text-success' : ev.status === 'ongoing' ? 'bg-primary/20 text-primary' : 'bg-surface-variant text-on-surface-variant'}`}>{ev.status}</span>
                </div>
                <Link to={`/events/${ev.id}`} className="font-bold text-lg text-on-surface hover:text-primary transition-colors mb-2">{ev.title}</Link>
                <p className="text-xs text-on-surface-variant leading-relaxed line-clamp-2 mb-4 flex-1">{ev.description}</p>
                <div className="space-y-1.5 text-xs font-label-caps uppercase text-outline mb-4">
                  <div className="flex items-center gap-1.5"><span className="material-symbols-outlined text-sm">schedule</span>{d.toLocaleDateString()} {d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}</div>
                  <div className="flex items-center gap-1.5"><span className="material-symbols-outlined text-sm">location_on</span>{ev.venue || 'TBD'}</div>
                  <div className="flex items-center gap-1.5"><span className="material-symbols-outlined text-sm">group</span>{ev.registeredCount} registered{ev.seatsLeft !== null && ` • ${ev.seatsLeft} seats left`}</div>
                </div>
                <div className="pt-3 border-t border-outline-variant/30 flex justify-between items-center">
                  {ev.isRegistered ? (
                    <div className="flex items-center gap-3">
                      <span className="text-success text-xs font-bold font-label-caps uppercase flex items-center gap-1"><span className="material-symbols-outlined text-sm">check_circle</span>Registered</span>
                      <label className="flex items-center gap-1.5 cursor-pointer">
                        <input type="checkbox" checked={ev.myRegistration?.notify ?? true} onChange={(e) => toggleNotify(ev.id, e.target.checked)} className="w-3.5 h-3.5 rounded border-outline-variant bg-surface text-primary focus:ring-primary focus:ring-offset-0"/>
                        <span className="text-[10px] text-on-surface-variant font-label-caps">Notify</span>
                      </label>
                    </div>
                  ) : (
                    <button onClick={() => handleRegister(ev.id)} className="bg-primary text-on-primary font-bold font-label-caps text-[10px] uppercase px-4 py-2 rounded hover:brightness-110 active:scale-[0.98] transition-all">Register</button>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      )}

      {showCreate && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-surface border border-outline-variant rounded-xl max-w-lg w-full p-6 shadow-xl overflow-y-auto max-h-[90vh]">
            <h3 className="font-headline-lg text-headline-lg text-on-surface mb-4">Create Event</h3>
            <form onSubmit={handleCreate} className="space-y-4">
              <div><label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Title</label><input type="text" value={form.title} onChange={e=>setForm({...form,title:e.target.value})} className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary" required/></div>
              <div><label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Description</label><textarea value={form.description} onChange={e=>setForm({...form,description:e.target.value})} className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm h-24 resize-none focus:ring-primary"/></div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Category</label><select value={form.category} onChange={e=>setForm({...form,category:e.target.value})} className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary"><option value="WORKSHOP">Workshop</option><option value="HACKATHON">Hackathon</option><option value="SEMINAR">Seminar</option><option value="COMPETITION">Competition</option><option value="OTHER">Other</option></select></div>
                <div><label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Venue</label><input type="text" value={form.venue} onChange={e=>setForm({...form,venue:e.target.value})} className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary"/></div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Event Date</label><input type="datetime-local" value={form.event_date} onChange={e=>setForm({...form,event_date:e.target.value})} className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary" required/></div>
                <div><label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Reg Deadline</label><input type="datetime-local" value={form.registration_deadline} onChange={e=>setForm({...form,registration_deadline:e.target.value})} className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary"/></div>
              </div>
              <div><label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Max Seats</label><input type="number" value={form.max_seats} onChange={e=>setForm({...form,max_seats:e.target.value})} className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary" placeholder="Leave empty for unlimited"/></div>
              <div className="flex justify-end gap-3 pt-2">
                <button type="button" onClick={()=>setShowCreate(false)} className="px-4 py-2 text-on-surface-variant hover:bg-surface-container-high rounded-lg font-label-caps text-xs uppercase">Cancel</button>
                <button type="submit" className="px-5 py-2 bg-primary text-on-primary rounded-lg font-bold font-label-caps text-xs uppercase hover:brightness-110">Create</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </main>
  )
}

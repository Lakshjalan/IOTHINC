import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useTeams } from '../hooks/useTeams'
import { useAuth } from '../hooks/useAuth'
import { supabase } from '../supabaseClient'

export const Teams = () => {
  const { role, user } = useAuth()
  const canCreate = role === 'admin' || role === 'coordinator'

  const { teams, loading, refetch } = useTeams()
  
  // Comm Feed state
  const [announcements, setAnnouncements] = useState([])
  const [newAnnouncement, setNewAnnouncement] = useState('')
  const [posting, setPosting] = useState(false)

  // Title Setup
  useEffect(() => {
    document.title = "Team Management - IOTHINC"
  }, [])

  const fetchAnnouncements = async () => {
    try {
      const { data, error } = await supabase
        .from('notifications')
        .select(`
          *,
          sender:profiles!notifications_sender_id_fkey(full_name, avatar_url)
        `)
        .eq('type', 'announcement')
        .order('created_at', { ascending: false })
        .limit(10)

      if (error) throw error
      setAnnouncements(data || [])
    } catch (err) {
      console.error(err)
    }
  }

  useEffect(() => {
    fetchAnnouncements()

    // Subscribe to announcements realtime updates
    const channel = supabase
      .channel('teams_announcements')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'notifications', filter: 'type=eq.announcement' },
        () => {
          fetchAnnouncements()
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [])

  const handlePostAnnouncement = async (e) => {
    e.preventDefault()
    if (!newAnnouncement.trim()) return
    setPosting(true)

    try {
      const { error } = await supabase
        .from('notifications')
        .insert({
          message: newAnnouncement,
          type: 'announcement',
          priority: role === 'admin' ? 1 : 2, // 1 for admin, 2 for coordinator
          target_role: 'all',
          sender_id: user.id
        })

      if (error) throw error
      setNewAnnouncement('')
      alert('Announcement posted successfully!')
      fetchAnnouncements()
    } catch (err) {
      alert('Error posting announcement: ' + err.message)
    } finally {
      setPosting(false)
    }
  }

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center min-h-[60vh]">
        <svg className="animate-spin h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path className="opacity-75" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" fill="currentColor"></path>
        </svg>
      </div>
    )
  }

  return (
    <main className="flex-1 px-4 md:px-stack-lg pt-24 pb-section-gap max-w-7xl mx-auto w-full animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="font-headline-xl text-headline-xl text-on-surface">Team Management</h2>
          <p className="font-body-md text-body-md text-on-surface-variant mt-2">
            Organise club subdivisions, map roles, and post broadcast notifications.
          </p>
        </div>
        
        {canCreate && (
          <Link 
            to="/teams/new"
            className="flex items-center gap-2 bg-primary text-on-primary font-bold font-label-caps text-xs uppercase px-4 py-3 rounded-lg hover:brightness-110 active:scale-[0.98] transition-all"
          >
            <span className="material-symbols-outlined">add</span>
            Create Team
          </Link>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Teams Directory List (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          <h3 className="font-headline-lg text-lg text-on-surface">Subdivision Teams</h3>
          {teams.length === 0 ? (
            <div className="bg-surface-container rounded-xl border border-outline-variant p-8 text-center text-on-surface-variant italic">
              No teams established yet.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {teams.map(team => (
                <div key={team.id} className="bg-surface-container rounded-xl border border-outline-variant p-5 shadow-sm hover:shadow-md transition-all">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h4 className="font-bold text-lg text-on-surface">{team.name}</h4>
                      <span className="text-[10px] font-label-caps text-on-surface-variant uppercase mt-1 block">
                        📁 Department: {team.department || 'General'}
                      </span>
                    </div>
                    <span className={`text-[10px] font-bold font-label-caps uppercase px-2 py-0.5 rounded ${team.status === 'active' ? 'bg-success/20 text-success' : 'bg-surface-variant text-on-surface-variant'}`}>
                      {team.status}
                    </span>
                  </div>

                  {/* Leader details */}
                  <div className="flex items-center gap-3 bg-surface-container-low border border-outline-variant/50 p-3 rounded-lg mb-4">
                    <img 
                      alt="" 
                      src={team.lead?.avatar_url || 'https://lh3.googleusercontent.com/aida-public/AB6AXuBNaqMiWFAn3N5e7M0gwmYiSokY3sIvWQwnYZMA0OyBqm4ptCO25QtOwdw1OQ5Rt5QTNH1uDqGHdu_L_t9wzqgFCLo5yIV_baf24Wf-xNCZxCaAlPkv5VLrFh3hXAREI068rYzK2DKm2y8Ru5FLCbUMv8cBS3F9GBx18Fv6wZ0tW9z9zXW40sIJ99UJvYbqJmHvgOnTlgxUFhS-L5JK-ZGbPBgMbAJbxIjoc14U41gx8HweiooxRjpNYkw-1cpZIXohA7GIseo7tbY'} 
                      className="w-8 h-8 rounded-full border border-outline-variant object-cover"
                    />
                    <div>
                      <span className="text-[10px] font-label-caps text-on-surface-variant uppercase">Team Lead</span>
                      <p className="text-xs font-semibold text-on-surface">{team.lead?.full_name || 'No Lead Assigned'}</p>
                    </div>
                  </div>

                  <div className="flex justify-between items-center text-xs font-label-caps text-outline uppercase pt-3 border-t border-outline-variant/30">
                    <span>👥 {team.memberCount} members</span>
                    <span>📁 {team.projectCount} active projects</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Comm Feed (4 cols) */}
        <div className="lg:col-span-4 bg-surface-container rounded-xl border border-outline-variant p-5 shadow-sm flex flex-col self-start">
          <h3 className="font-headline-lg text-lg text-on-surface mb-4">Comm Feed</h3>
          
          {/* Post update (Admin/Coordinator only) */}
          {canCreate && (
            <form onSubmit={handlePostAnnouncement} className="mb-6 pb-6 border-b border-outline-variant/30 space-y-3">
              <textarea 
                value={newAnnouncement}
                onChange={(e) => setNewAnnouncement(e.target.value)}
                className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-xs h-20 resize-none focus:ring-primary focus:border-primary"
                placeholder="Post a new announcement updates to the team feed..."
                required
              />
              <button 
                type="submit"
                disabled={posting}
                className="w-full bg-primary text-on-primary font-bold font-label-caps text-[10px] uppercase py-2.5 rounded hover:brightness-110 active:scale-[0.98] transition-all disabled:opacity-50"
              >
                {posting ? 'Posting...' : 'Post Update'}
              </button>
            </form>
          )}

          {/* List announcements */}
          <div className="space-y-4 max-h-[350px] overflow-y-auto no-scrollbar">
            {announcements.length === 0 ? (
              <p className="text-xs text-on-surface-variant italic text-center py-6">No announcements posted.</p>
            ) : (
              announcements.map(ann => (
                <div key={ann.id} className="p-3 bg-surface-container-low border border-outline-variant rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <img 
                      alt="" 
                      src={ann.sender?.avatar_url || 'https://lh3.googleusercontent.com/aida-public/AB6AXuBNaqMiWFAn3N5e7M0gwmYiSokY3sIvWQwnYZMA0OyBqm4ptCO25QtOwdw1OQ5Rt5QTNH1uDqGHdu_L_t9wzqgFCLo5yIV_baf24Wf-xNCZxCaAlPkv5VLrFh3hXAREI068rYzK2DKm2y8Ru5FLCbUMv8cBS3F9GBx18Fv6wZ0tW9z9zXW40sIJ99UJvYbqJmHvgOnTlgxUFhS-L5JK-ZGbPBgMbAJbxIjoc14U41gx8HweiooxRjpNYkw-1cpZIXohA7GIseo7tbY'} 
                      className="w-6 h-6 rounded-full object-cover"
                    />
                    <span className="font-semibold text-xs text-on-surface">{ann.sender?.full_name || 'System'}</span>
                  </div>
                  <p className="text-xs text-on-surface-variant leading-relaxed">{ann.message}</p>
                  <span className="text-[9px] text-outline font-label-caps uppercase mt-2 block">
                    {new Date(ann.created_at).toLocaleDateString()}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

    </main>
  )
}

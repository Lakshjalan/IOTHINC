import React, { useState, useEffect } from 'react'
import { useParams, useNavigate, Link } from 'react-router-dom'
import { supabase } from '../supabaseClient'
import { useAuth } from '../hooks/useAuth'

export const ProjectDetail = () => {
  const { id } = useParams()
  const navigate = useNavigate()
  const { role } = useAuth()
  const canModify = role === 'admin' || role === 'coordinator'

  const [project, setProject] = useState(null)
  const [tasks, setTasks] = useState([])
  const [contributions, setContributions] = useState([])
  const [loading, setLoading] = useState(true)

  const fetchProjectDetails = async () => {
    setLoading(true)
    try {
      // 1. Fetch Project
      const { data: proj, error: projErr } = await supabase
        .from('projects')
        .select('*, teams(id, name)')
        .eq('id', id)
        .single()

      if (projErr) throw projErr
      setProject(proj)
      document.title = `${proj.title} | IOTHINC`

      // 2. Fetch Tasks
      const { data: tsk } = await supabase
        .from('tasks')
        .select('*, assignee:profiles!tasks_assigned_to_fkey(full_name, avatar_url)')
        .eq('project_id', id)
      setTasks(tsk || [])

      // 3. Fetch Contributions
      const { data: contr } = await supabase
        .from('contributions')
        .select('*, member:profiles!contributions_member_id_fkey(full_name, avatar_url)')
        .eq('project_id', id)
      setContributions(contr || [])

    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchProjectDetails()
  }, [id])

  const handleProgressChange = async (newVal) => {
    try {
      const { error } = await supabase
        .from('projects')
        .update({ progress: newVal })
        .eq('id', id)

      if (error) throw error
      setProject(prev => ({ ...prev, progress: newVal }))
    } catch (err) {
      alert('Error: ' + err.message)
    }
  }

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center min-h-[60vh]">
        <svg className="animate-spin h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path className="opacity-75" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" fill="currentColor"></path>
        </svg>
      </div>
    )
  }

  return (
    <main className="flex-1 px-4 md:px-stack-lg pt-24 pb-section-gap max-w-5xl mx-auto w-full animate-in fade-in duration-200">
      
      {/* Back Button */}
      <button 
        onClick={() => navigate('/projects')}
        className="flex items-center gap-1.5 text-on-surface-variant hover:text-primary mb-6 text-sm font-label-caps font-bold uppercase transition-colors"
      >
        <span className="material-symbols-outlined text-lg">arrow_back</span>
        Back to projects
      </button>

      {/* Project Card */}
      <div className="bg-surface-container rounded-xl border border-outline-variant p-6 md:p-8 shadow-sm mb-8">
        <div className="flex justify-between items-start flex-wrap gap-4 mb-4">
          <div>
            <span className="text-[10px] font-bold font-label-caps uppercase text-primary tracking-wider bg-primary-container/10 px-2 py-1 rounded">
              {project?.category || 'General'}
            </span>
            <h2 className="font-headline-xl text-3xl text-on-surface mt-2 font-bold">{project?.title}</h2>
          </div>
          
          <div className="text-right">
            <span className="block text-[10px] font-label-caps text-on-surface-variant uppercase">Status</span>
            <span className={`inline-block text-xs font-bold font-label-caps uppercase px-2.5 py-1 rounded-full mt-1 ${project?.status === 'completed' ? 'bg-success/20 text-success' : project?.status === 'active' ? 'bg-primary/20 text-primary' : 'bg-surface-variant text-on-surface-variant'}`}>
              {project?.status}
            </span>
          </div>
        </div>

        <p className="text-on-surface-variant text-sm leading-relaxed mb-6 whitespace-pre-wrap">{project?.description}</p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t border-outline-variant/30">
          <div>
            <span className="block text-[10px] font-label-caps text-on-surface-variant uppercase">Milestone</span>
            <p className="text-sm font-semibold text-on-surface mt-1">{project?.milestone || 'N/A'}</p>
          </div>
          <div>
            <span className="block text-[10px] font-label-caps text-on-surface-variant uppercase">Deadline</span>
            <p className="text-sm font-semibold text-on-surface mt-1">{project?.deadline || 'N/A'}</p>
          </div>
          <div>
            <span className="block text-[10px] font-label-caps text-on-surface-variant uppercase mb-1">Progress ({project?.progress}%)</span>
            {canModify ? (
              <input 
                type="range" 
                min="0" 
                max="100" 
                value={project?.progress || 0}
                onChange={(e) => handleProgressChange(parseInt(e.target.value))}
                className="w-full accent-primary h-1.5 rounded-lg bg-surface-container-highest cursor-pointer"
              />
            ) : (
              <div className="w-full bg-surface-container-highest rounded-full h-2 mt-2">
                <div className="bg-primary h-2 rounded-full" style={{ width: `${project?.progress}%` }} />
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Tasks Section (7 cols) */}
        <div className="lg:col-span-7 bg-surface-container rounded-xl border border-outline-variant p-5 shadow-sm">
          <h3 className="font-headline-lg text-lg text-on-surface mb-4">Linked Tasks</h3>
          {tasks.length === 0 ? (
            <p className="text-sm text-on-surface-variant italic text-center p-4">No tasks linked to this project yet.</p>
          ) : (
            <div className="space-y-3">
              {tasks.map(task => (
                <div key={task.id} className="p-3 bg-surface-container-low border border-outline-variant rounded-lg flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-sm text-on-surface">{task.title}</h4>
                    <span className="text-[10px] text-on-surface-variant font-label-caps uppercase mt-1 block">
                      Assigned to: {task.assignee?.full_name || 'Unassigned'}
                    </span>
                  </div>
                  <span className={`text-[10px] font-bold font-label-caps uppercase px-2 py-0.5 rounded ${task.status === 'completed' ? 'bg-success/20 text-success' : task.status === 'in_progress' ? 'bg-primary/20 text-primary' : 'bg-surface-variant text-on-surface-variant'}`}>
                    {task.status.replace('_', ' ')}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Contributions Section (5 cols) */}
        <div className="lg:col-span-5 bg-surface-container rounded-xl border border-outline-variant p-5 shadow-sm">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-headline-lg text-lg text-on-surface">Contributions</h3>
            <Link 
              to={`/contributions/new?project_id=${id}`}
              className="text-primary font-label-caps text-xs uppercase hover:underline"
            >
              Log New
            </Link>
          </div>
          {contributions.length === 0 ? (
            <p className="text-sm text-on-surface-variant italic text-center p-4">No logged contributions.</p>
          ) : (
            <div className="space-y-4">
              {contributions.map(c => (
                <div key={c.id} className="p-3 bg-surface-container-low border border-outline-variant rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <img 
                      alt="" 
                      src={c.member?.avatar_url || 'https://lh3.googleusercontent.com/aida-public/AB6AXuBNaqMiWFAn3N5e7M0gwmYiSokY3sIvWQwnYZMA0OyBqm4ptCO25QtOwdw1OQ5Rt5QTNH1uDqGHdu_L_t9wzqgFCLo5yIV_baf24Wf-xNCZxCaAlPkv5VLrFh3hXAREI068rYzK2DKm2y8Ru5FLCbUMv8cBS3F9GBx18Fv6wZ0tW9z9zXW40sIJ99UJvYbqJmHvgOnTlgxUFhS-L5JK-ZGbPBgMbAJbxIjoc14U41gx8HweiooxRjpNYkw-1cpZIXohA7GIseo7tbY'} 
                      className="w-6 h-6 rounded-full border border-outline-variant object-cover"
                    />
                    <span className="font-semibold text-xs text-on-surface">{c.member?.full_name}</span>
                  </div>
                  <h4 className="font-bold text-sm text-on-surface mb-1">{c.title}</h4>
                  <p className="text-xs text-on-surface-variant leading-relaxed line-clamp-3">{c.description}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

    </main>
  )
}

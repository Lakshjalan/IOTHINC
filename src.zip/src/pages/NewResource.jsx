import React, { useState, useEffect } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth'
import { supabase } from '../supabaseClient'

export const NewResource = () => {
  const { user, role } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ title: '', type: 'VIDEO', description: '', url: '', track: '', duration_mins: '' })
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => { document.title = "IOTHINC - Training & Learning" }, [])

  if (role !== 'admin') return <main className="flex-1 px-4 md:px-stack-lg pt-24 pb-section-gap max-w-7xl mx-auto w-full"><div className="text-center text-error text-lg mt-20">Access denied. Admin only.</div></main>

  const handleSubmit = async (e) => {
    e.preventDefault()
    setSubmitting(true)
    try {
      const { error } = await supabase.from('learning_resources').insert({
        title: form.title, type: form.type, description: form.description || null,
        url: form.url || null, track: form.track || null,
        duration_mins: form.duration_mins ? parseInt(form.duration_mins) : null,
        uploaded_by: user.id
      })
      if (error) throw error
      alert('Resource created successfully!')
      navigate('/learn')
    } catch (err) { alert('Error: ' + err.message) }
    setSubmitting(false)
  }

  return (
    <main className="flex-1 px-4 md:px-stack-lg pt-24 pb-section-gap max-w-7xl mx-auto w-full">
      <Link to="/learn" className="inline-flex items-center gap-1.5 text-primary text-sm hover:underline mb-6">
        <span className="material-symbols-outlined text-lg">arrow_back</span>Back to Learning
      </Link>

      <div className="max-w-2xl mx-auto">
        <h2 className="font-headline-xl text-headline-xl text-on-surface mb-2">Add New Resource</h2>
        <p className="font-body-md text-body-md text-on-surface-variant mb-8">Create a learning resource for club members.</p>

        <form onSubmit={handleSubmit} className="bg-surface-container rounded-xl border border-outline-variant p-6 shadow-sm space-y-5">
          <div><label className="block text-xs font-label-caps text-on-surface-variant mb-1.5 uppercase">Title</label><input type="text" value={form.title} onChange={e => setForm({...form, title: e.target.value})} className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary" required/></div>
          <div><label className="block text-xs font-label-caps text-on-surface-variant mb-1.5 uppercase">Type</label><select value={form.type} onChange={e => setForm({...form, type: e.target.value})} className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary"><option value="VIDEO">Video</option><option value="ARTICLE">Article</option><option value="PDF">PDF</option><option value="WORKSHOP">Workshop</option></select></div>
          <div><label className="block text-xs font-label-caps text-on-surface-variant mb-1.5 uppercase">Description</label><textarea value={form.description} onChange={e => setForm({...form, description: e.target.value})} className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm h-28 resize-none focus:ring-primary" placeholder="What does this resource cover?"/></div>
          <div><label className="block text-xs font-label-caps text-on-surface-variant mb-1.5 uppercase">URL</label><input type="url" value={form.url} onChange={e => setForm({...form, url: e.target.value})} className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary" placeholder="https://..."/></div>
          <div className="grid grid-cols-2 gap-4">
            <div><label className="block text-xs font-label-caps text-on-surface-variant mb-1.5 uppercase">Track</label><input type="text" value={form.track} onChange={e => setForm({...form, track: e.target.value})} className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary" placeholder="e.g. IoT Basics"/></div>
            <div><label className="block text-xs font-label-caps text-on-surface-variant mb-1.5 uppercase">Duration (min)</label><input type="number" value={form.duration_mins} onChange={e => setForm({...form, duration_mins: e.target.value})} className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary" min="1"/></div>
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Link to="/learn" className="px-4 py-2.5 text-on-surface-variant hover:bg-surface-container-high rounded-lg font-label-caps text-xs uppercase">Cancel</Link>
            <button type="submit" disabled={submitting} className="px-6 py-2.5 bg-primary text-on-primary rounded-lg font-bold font-label-caps text-xs uppercase hover:brightness-110 disabled:opacity-50 transition-all">{submitting ? 'Creating...' : 'Create Resource'}</button>
          </div>
        </form>
      </div>
    </main>
  )
}

import React, { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { supabase } from '../supabaseClient'
import { useAuth } from '../hooks/useAuth'

export const Competitions = () => {
  const navigate = useNavigate()
  const { role, user } = useAuth()
  const canHost = role === 'admin' || role === 'coordinator'

  const [competitions, setCompetitions] = useState([])
  const [loading, setLoading] = useState(true)
  
  // Submission form modal state
  const [showSubmitModal, setShowSubmitModal] = useState(false)
  const [targetComp, setTargetComp] = useState(null)
  const [teamName, setTeamName] = useState('')
  const [submitting, setSubmitting] = useState(false)

  const fetchCompetitions = async () => {
    setLoading(true)
    try {
      const { data, error } = await supabase
        .from('competitions')
        .select(`
          *,
          host:profiles!competitions_hosted_by_fkey(full_name),
          submissions:competition_submissions(id, member_id, status)
        `)
        .order('created_at', { ascending: false })

      if (error) throw error
      setCompetitions(data || [])
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    document.title = "Competitions | IOTHINC"
    fetchCompetitions()
  }, [])

  const handleSubmitEntry = async (e) => {
    e.preventDefault()
    if (!targetComp || !user) return
    setSubmitting(true)

    try {
      const { error } = await supabase
        .from('competition_submissions')
        .insert({
          competition_id: targetComp.id,
          member_id: user.id,
          team_name: teamName,
          status: 'submitted'
        })

      if (error) throw error
      alert('Entry submitted successfully!')
      setShowSubmitModal(false)
      setTeamName('')
      fetchCompetitions()
    } catch (err) {
      alert('Error submitting entry: ' + err.message)
    } finally {
      setSubmitting(false)
    }
  }

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center min-h-[60vh]">
        <svg className="animate-spin h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path className="opacity-75" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" fill="currentColor"></path>
        </svg>
      </div>
    )
  }

  return (
    <main className="flex-1 px-4 md:px-stack-lg pt-24 pb-section-gap max-w-7xl mx-auto w-full animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="font-headline-xl text-headline-xl text-on-surface">Competitions</h2>
          <p className="font-body-md text-body-md text-on-surface-variant mt-2">
            Participate in hackathons, tracks, coding contests, and win exciting prizes.
          </p>
        </div>
        
        {canHost && (
          <Link 
            to="/competitions/host"
            className="flex items-center gap-2 bg-primary text-on-primary font-bold font-label-caps text-xs uppercase px-4 py-3 rounded-lg hover:brightness-110 active:scale-[0.98] transition-all"
          >
            <span className="material-symbols-outlined">add</span>
            Host Competition
          </Link>
        )}
      </div>

      {/* Grid of Competitions */}
      {competitions.length === 0 ? (
        <div className="bg-surface-container rounded-xl border border-outline-variant p-8 text-center text-on-surface-variant italic">
          No active competitions tracked.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {competitions.map(comp => {
            const hasSubmitted = comp.submissions?.some(s => s.member_id === user?.id)
            const isDeadlinePassed = new Date(comp.registration_deadline) < new Date()

            return (
              <div key={comp.id} className="bg-surface-container rounded-xl border border-outline-variant p-5 flex flex-col shadow-sm justify-between">
                <div>
                  <div className="flex justify-between items-start mb-4">
                    <span className="text-[10px] font-bold font-label-caps uppercase text-primary tracking-wider bg-primary-container/10 px-2 py-0.5 rounded">
                      {comp.type.replace('_', ' ')}
                    </span>
                    <span className={`text-[10px] font-bold font-label-caps uppercase px-2 py-0.5 rounded ${comp.status === 'active' ? 'bg-success/20 text-success' : 'bg-surface-variant text-on-surface-variant'}`}>
                      {comp.status}
                    </span>
                  </div>

                  <h3 className="font-bold text-lg text-on-surface mb-2">{comp.title}</h3>
                  <p className="text-xs text-on-surface-variant leading-relaxed mb-4 line-clamp-3">{comp.description}</p>
                  
                  {/* Metadata list */}
                  <div className="space-y-2 text-xs font-label-caps uppercase text-outline mb-6">
                    <div className="flex items-center gap-1.5">
                      <span className="material-symbols-outlined text-sm">payments</span>
                      <span>Prize Pool: <strong className="text-on-surface">{comp.prize_pool || 'TBD'}</strong></span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="material-symbols-outlined text-sm">groups</span>
                      <span>Format: <strong className="text-on-surface">{comp.format}</strong></span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="material-symbols-outlined text-sm">schedule</span>
                      <span>Starts: {new Date(comp.start_date).toLocaleDateString()}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-error">
                      <span className="material-symbols-outlined text-sm text-error">timer</span>
                      <span>Deadline: {new Date(comp.registration_deadline).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-outline-variant/30 flex justify-between items-center">
                  {hasSubmitted ? (
                    <span className="text-success text-xs font-bold font-label-caps uppercase flex items-center gap-1">
                      <span className="material-symbols-outlined text-sm">check_circle</span>
                      Submitted
                    </span>
                  ) : isDeadlinePassed ? (
                    <span className="text-on-surface-variant/50 text-xs font-bold font-label-caps uppercase">
                      Closed
                    </span>
                  ) : (
                    <button 
                      onClick={() => {
                        setTargetComp(comp)
                        setShowSubmitModal(true)
                      }}
                      className="bg-primary text-on-primary font-bold font-label-caps text-[10px] uppercase px-4 py-2.5 rounded hover:brightness-110 active:scale-[0.98] transition-all"
                    >
                      Submit Entry
                    </button>
                  )}
                  
                  <span className="text-[10px] text-outline font-label-caps uppercase">
                    Hosted by {comp.host?.full_name || 'System'}
                  </span>
                </div>
              </div>
            )
          })}
        </div>
      )}

      {/* Submission Modal */}
      {showSubmitModal && targetComp && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-surface border border-outline-variant rounded-xl max-w-md w-full p-6 shadow-xl animate-in fade-in zoom-in duration-200">
            <h3 className="font-headline-lg text-headline-lg text-on-surface mb-2">Submit Entry</h3>
            <p className="text-xs text-on-surface-variant mb-4 font-label-caps uppercase">
              Competition: {targetComp.title}
            </p>
            <form onSubmit={handleSubmitEntry} className="space-y-4">
              <div>
                <label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Team Name / Solo Alias</label>
                <input 
                  type="text" 
                  value={teamName}
                  onChange={(e) => setTeamName(e.target.value)}
                  className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary focus:border-primary"
                  placeholder="e.g. Code_Crusaders"
                  required
                />
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button 
                  type="button" 
                  onClick={() => {
                    setShowSubmitModal(false)
                    setTeamName('')
                  }}
                  className="px-4 py-2 text-on-surface-variant hover:bg-surface-container-high rounded-lg font-label-caps text-xs uppercase"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  disabled={submitting}
                  className="px-5 py-2 bg-primary text-on-primary rounded-lg font-bold font-label-caps text-xs uppercase hover:brightness-110 disabled:opacity-50"
                >
                  {submitting ? 'Submitting...' : 'Submit'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </main>
  )
}

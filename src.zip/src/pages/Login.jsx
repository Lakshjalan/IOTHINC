import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth'

export const Login = () => {
  const navigate = useNavigate()
  const { signIn, signUp, user } = useAuth()
  
  // Title Setup
  useEffect(() => {
    document.title = "IOTHINC | Sign In"
  }, [])

  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      navigate('/dashboard')
    }
  }, [user, navigate])

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [isRegisterMode, setIsRegisterMode] = useState(false)
  const [fullName, setFullName] = useState('')
  
  // Status states
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [errorMsg, setErrorMsg] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setErrorMsg('')
    setSuccess(false)

    try {
      if (isRegisterMode) {
        // Sign Up Mode
        if (!fullName.trim()) throw new Error("Full name is required")
        await signUp(email, password, fullName)
        setSuccess(true)
        alert("Registration request submitted! Your account is pending administrator approval.")
        setIsRegisterMode(false)
      } else {
        // Sign In Mode
        await signIn(email, password)
        setSuccess(true)
        setTimeout(() => {
          navigate('/dashboard')
        }, 1000)
      }
    } catch (err) {
      console.error(err)
      setErrorMsg(err.message || 'Authentication failed. Please verify your inputs.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen flex flex-col md:flex-row bg-[#0A0A0C] text-white select-none">
      {/* LEFT PANEL: Brand & Impact */}
      <section className="w-full md:w-[45%] relative overflow-hidden flex flex-col justify-between p-12 min-h-[40vh] md:min-h-screen">
        <div className="absolute inset-0 grid-overlay pointer-events-none"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-primary/20 blur-[120px] rounded-full glow-pulse pointer-events-none"></div>
        
        {/* Logo */}
        <img 
          src="https://lh3.googleusercontent.com/aida-public/AB6AXuBxy40qeuMnls3d06xw0t5kGox9RUht3mkvxVfsRVQ9ldTgkrCudYy5N9CdhkzQbs-jPw8UuPENeSuX8oy3bVXhahrKbSTuYJcOlaDbPMSY3lAbO7CEIYGa_GeVeZJkmBIFh1btUx6ZB8TSPJbyoyGo1guSAn5Xjxx89sn6NTqKNTaPQdP1uBTPfI0F15QEZIvqfmavGM5uUexHIY2J2UqoQy9JgR6dnejoLavjUYTK1wXGk_6poaTxLm-6mQPkUFzteXmYha6p0_4" 
          alt="IOTHINC Logo" 
          className="absolute top-6 left-6 w-[120px] h-auto block z-10 object-contain"
        />

        {/* Content */}
        <div className="relative z-10 max-w-md mt-16 md:mt-24">
          <h1 className="font-syne font-extrabold text-4xl md:text-5xl leading-tight mb-6">
            Manage your club, track your progress,<br />
            <span className="text-primary-fixed-dim">build together.</span>
          </h1>
          <p className="text-muted text-base mb-10 leading-relaxed">
            A unified platform for events, contributions, team coordination, and member growth.
          </p>
          
          {/* Stat Chips */}
          <div className="flex flex-col gap-4">
            <div className="bg-surface-container-high border border-white/10 rounded-base p-4 flex items-center gap-4 w-fit pr-8">
              <div className="w-2.5 h-2.5 rounded-full bg-success shadow-[0_0_8px_rgba(62,207,142,0.8)]"></div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg">85</span>
                <span className="text-muted text-sm">Active members</span>
              </div>
            </div>
            <div className="bg-surface-container-high border border-white/10 rounded-base p-4 flex items-center gap-4 w-fit pr-8">
              <div className="w-2.5 h-2.5 rounded-full bg-primary shadow-[0_0_8px_rgba(124,92,252,0.8)]"></div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg">12</span>
                <span className="text-muted text-sm">Projects in progress</span>
              </div>
            </div>
            <div className="bg-surface-container-high border border-white/10 rounded-base p-4 flex items-center gap-4 w-fit pr-8">
              <div className="w-2.5 h-2.5 rounded-full bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.8)]"></div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg">3</span>
                <span className="text-muted text-sm">Upcoming events</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="relative z-10 mt-8">
          <p className="text-xs text-muted/50 font-medium">
            © 2026 TechClub Management System.
          </p>
        </div>
      </section>

      {/* RIGHT PANEL: Authentication */}
      <section className="w-full md:w-[55%] flex flex-col items-center justify-center p-8 md:p-12 relative overflow-y-auto min-h-[60vh] md:min-h-screen">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-primary/5 blur-[100px] rounded-full pointer-events-none"></div>
        <div className="w-full max-w-[420px] relative z-10">
          
          {/* Header */}
          <div className="mb-10 text-center">
            <h2 className="font-syne font-bold text-[28px] text-white mb-2">
              {isRegisterMode ? "Create Account" : "Welcome back"}
            </h2>
            <p className="text-[13px] text-muted">
              {isRegisterMode ? "Register a new member profile" : "Sign in to your TechClub account"}
            </p>
          </div>

          {/* Form */}
          <form className="space-y-5" onSubmit={handleSubmit}>
            {isRegisterMode && (
              <div className="space-y-2">
                <div className="relative flex items-center bg-[#111116] border border-white/10 rounded-base h-[46px] px-4 input-focus-ring transition-all group">
                  <span className="material-symbols-outlined text-muted text-xl mr-3 group-focus-within:text-primary">badge</span>
                  <input 
                    className="w-full bg-transparent border-none p-0 text-sm focus:ring-0 placeholder:text-muted/50 text-white" 
                    placeholder="Full Name" 
                    type="text" 
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    required
                  />
                </div>
              </div>
            )}

            {/* Email */}
            <div className="space-y-2">
              <div className="relative flex items-center bg-[#111116] border border-white/10 rounded-base h-[46px] px-4 input-focus-ring transition-all group">
                <span className="material-symbols-outlined text-muted text-xl mr-3 group-focus-within:text-primary">mail</span>
                <input 
                  className="w-full bg-transparent border-none p-0 text-sm focus:ring-0 placeholder:text-muted/50 text-white" 
                  placeholder="name@nexusclub.com" 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
            </div>

            {/* Password */}
            <div className="space-y-2">
              <div className="relative flex items-center bg-[#111116] border border-white/10 rounded-base h-[46px] px-4 input-focus-ring transition-all group">
                <span className="material-symbols-outlined text-muted text-xl mr-3 group-focus-within:text-primary">lock</span>
                <input 
                  className="w-full bg-transparent border-none p-0 text-sm focus:ring-0 placeholder:text-muted/50 text-white" 
                  placeholder="••••••••" 
                  type={showPassword ? "text" : "password"} 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <button 
                  className="ml-2 text-muted hover:text-white transition-colors focus:outline-none" 
                  onClick={() => setShowPassword(!showPassword)} 
                  type="button"
                >
                  <span className="material-symbols-outlined text-xl">
                    {showPassword ? 'visibility_off' : 'visibility'}
                  </span>
                </button>
              </div>
            </div>

            {/* Row: Options (Only in sign-in mode) */}
            {!isRegisterMode && (
              <div className="flex items-center justify-between text-[13px]">
                <label className="flex items-center gap-2 cursor-pointer group">
                  <input className="w-4 h-4 rounded border-white/20 bg-[#111116] text-primary focus:ring-primary focus:ring-offset-0" type="checkbox" />
                  <span className="text-muted group-hover:text-white transition-colors">Remember me</span>
                </label>
                <a className="text-primary hover:text-primary-muted font-medium" href="#forgot">Forgot password?</a>
              </div>
            )}

            {/* Error Message */}
            {errorMsg && (
              <p className="text-xs text-error font-medium text-center bg-error/10 py-2 rounded">
                ⚠️ {errorMsg}
              </p>
            )}

            {/* Success Loading Trigger */}
            {success && !isRegisterMode && (
              <div className="bg-success/15 border border-success/30 rounded-base p-4 flex items-center justify-center gap-2 success-shadow text-success text-sm font-bold animate-pulse">
                <span className="material-symbols-outlined text-xl">check_circle</span>
                <span>✓ Welcome back! Redirecting...</span>
              </div>
            )}

            {/* Actions */}
            <div className="pt-4 space-y-4">
              {loading ? (
                <button className="w-full h-[48px] bg-primary/70 text-white font-bold rounded-base cursor-not-allowed flex items-center justify-center gap-3" disabled>
                  <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path className="opacity-75" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" fill="currentColor"></path>
                  </svg>
                  <span>Authenticating...</span>
                </button>
              ) : (
                <button className="w-full h-[48px] bg-primary text-white font-bold rounded-base btn-shadow hover:brightness-110 active:scale-[0.99] transition-all" type="submit">
                  {isRegisterMode ? "Submit Registration Request" : "Sign In"}
                </button>
              )}

              <button 
                className="w-full h-[48px] bg-transparent border border-white/10 text-muted font-medium rounded-base hover:bg-white/5 active:scale-[0.99] transition-all" 
                type="button"
                onClick={() => setIsRegisterMode(!isRegisterMode)}
              >
                {isRegisterMode ? "Already have an account? Sign In" : "Request Account Access"}
              </button>
            </div>
          </form>

          {/* Role Strip */}
          <div className="mt-8 flex items-center justify-center gap-6 py-4 border-t border-white/5">
            <span className="text-[12px] uppercase tracking-wider text-muted font-bold">Roles:</span>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-red-500"></div>
                <span className="text-[12px] text-muted font-medium">Admin</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-amber-500"></div>
                <span className="text-[12px] text-muted font-medium">Coordinator</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-full bg-primary"></div>
                <span className="text-[12px] text-muted font-medium">Member</span>
              </div>
            </div>
          </div>

        </div>
      </section>
    </main>
  )
}

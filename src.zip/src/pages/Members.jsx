import React, { useState } from 'react'
import { useMembers } from '../hooks/useMembers'
import { useAuth } from '../hooks/useAuth'

export const Members = () => {
  const { role } = useAuth()
  const isAdmin = role === 'admin'

  const [filters, setFilters] = useState({
    department: '',
    year: '',
    role: ''
  })

  const { members, loading, addMember, updateMember, deleteMember } = useMembers(filters)
  
  // Selected member side panel state
  const [selectedMember, setSelectedMember] = useState(null)
  
  // Dialog states
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [showEditDialog, setShowEditDialog] = useState(false)
  const [editForm, setEditForm] = useState(null)
  const [newMemberForm, setNewMemberForm] = useState({
    full_name: '',
    email: '',
    role: 'member',
    department: '',
    year: '',
    skills: '',
    bio: ''
  })

  // Set title
  React.useEffect(() => {
    document.title = "Member Directory | IOTHINC"
  }, [])

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }))
  }

  const handleAddSubmit = async (e) => {
    e.preventDefault()
    try {
      const skillsArray = newMemberForm.skills ? newMemberForm.skills.split(',').map(s => s.trim()) : []
      // Note: This inserts the profile row. (Requires auth account created first in real system, but can mock insert)
      await addMember({
        ...newMemberForm,
        skills: skillsArray,
        needs_approval: false
      })
      setShowAddDialog(false)
      setNewMemberForm({
        full_name: '',
        email: '',
        role: 'member',
        department: '',
        year: '',
        skills: '',
        bio: ''
      })
      alert('Member added successfully!')
    } catch (err) {
      alert('Error: ' + err.message)
    }
  }

  const handleEditSubmit = async (e) => {
    e.preventDefault()
    try {
      const skillsArray = typeof editForm.skills === 'string' 
        ? editForm.skills.split(',').map(s => s.trim()) 
        : editForm.skills

      await updateMember(editForm.id, {
        full_name: editForm.full_name,
        email: editForm.email,
        role: editForm.role,
        department: editForm.department,
        year: editForm.year,
        skills: skillsArray,
        bio: editForm.bio
      })
      setShowEditDialog(false)
      setSelectedMember(null)
      alert('Member updated successfully!')
    } catch (err) {
      alert('Error: ' + err.message)
    }
  }

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this member?')) return
    try {
      await deleteMember(id)
      setSelectedMember(null)
      alert('Member deleted.')
    } catch (err) {
      alert('Error deleting member: ' + err.message)
    }
  }

  return (
    <main className="flex-1 px-4 md:px-stack-lg pt-24 pb-section-gap max-w-7xl mx-auto w-full animate-in fade-in duration-200">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="font-headline-xl text-headline-xl text-on-surface">Member Directory</h2>
          <p className="font-body-md text-body-md text-on-surface-variant mt-2">
            Browse and coordinate with club members across teams and tracks.
          </p>
        </div>
        {isAdmin && (
          <button 
            onClick={() => setShowAddDialog(true)}
            className="flex items-center gap-2 bg-primary text-on-primary font-bold font-label-caps text-xs uppercase px-4 py-3 rounded-lg hover:brightness-110 active:scale-[0.98] transition-all"
          >
            <span className="material-symbols-outlined">add</span>
            Add Member
          </button>
        )}
      </div>

      {/* Filter Row */}
      <div className="bg-surface-container rounded-xl border border-outline-variant p-4 mb-6 flex flex-wrap gap-4 items-center">
        <div>
          <label className="block text-[10px] font-label-caps text-on-surface-variant uppercase mb-1">Department</label>
          <select 
            value={filters.department}
            onChange={(e) => handleFilterChange('department', e.target.value)}
            className="bg-surface-container-low text-on-surface text-sm p-2 rounded-lg border border-outline-variant focus:outline-none"
          >
            <option value="">All Departments</option>
            <option value="Computer Science">Computer Science</option>
            <option value="Electronics">Electronics</option>
            <option value="Mechanical">Mechanical</option>
          </select>
        </div>
        <div>
          <label className="block text-[10px] font-label-caps text-on-surface-variant uppercase mb-1">Academic Year</label>
          <select 
            value={filters.year}
            onChange={(e) => handleFilterChange('year', e.target.value)}
            className="bg-surface-container-low text-on-surface text-sm p-2 rounded-lg border border-outline-variant focus:outline-none"
          >
            <option value="">All Years</option>
            <option value="1st Year">1st Year</option>
            <option value="2nd Year">2nd Year</option>
            <option value="3rd Year">3rd Year</option>
            <option value="4th Year">4th Year</option>
          </select>
        </div>
        <div>
          <label className="block text-[10px] font-label-caps text-on-surface-variant uppercase mb-1">Role</label>
          <select 
            value={filters.role}
            onChange={(e) => handleFilterChange('role', e.target.value)}
            className="bg-surface-container-low text-on-surface text-sm p-2 rounded-lg border border-outline-variant focus:outline-none"
          >
            <option value="">All Roles</option>
            <option value="admin">Admin</option>
            <option value="coordinator">Coordinator</option>
            <option value="member">Member</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Table List Area */}
        <div className={`${selectedMember ? 'lg:col-span-8' : 'lg:col-span-12'} bg-surface-container rounded-xl border border-outline-variant overflow-hidden shadow-sm transition-all duration-200`}>
          {loading ? (
            <div className="p-8 text-center">
              <svg className="animate-spin h-6 w-6 text-primary mx-auto" fill="none" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                <path className="opacity-75" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" fill="currentColor"></path>
              </svg>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-outline-variant bg-surface-container-low text-[10px] font-label-caps uppercase text-on-surface-variant">
                    <th className="p-4">Name</th>
                    <th className="p-4">Email</th>
                    <th className="p-4">Department</th>
                    <th className="p-4 text-center">Contributions</th>
                    {isAdmin && <th className="p-4 text-right">Actions</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-outline-variant">
                  {members.map(member => (
                    <tr 
                      key={member.id} 
                      onClick={() => setSelectedMember(member)}
                      className={`hover:bg-surface-container-high transition-colors cursor-pointer ${selectedMember?.id === member.id ? 'bg-primary-container/10' : ''}`}
                    >
                      <td className="p-4 flex items-center gap-3">
                        <img 
                          alt="" 
                          src={member.avatar_url || 'https://lh3.googleusercontent.com/aida-public/AB6AXuBNaqMiWFAn3N5e7M0gwmYiSokY3sIvWQwnYZMA0OyBqm4ptCO25QtOwdw1OQ5Rt5QTNH1uDqGHdu_L_t9wzqgFCLo5yIV_baf24Wf-xNCZxCaAlPkv5VLrFh3hXAREI068rYzK2DKm2y8Ru5FLCbUMv8cBS3F9GBx18Fv6wZ0tW9z9zXW40sIJ99UJvYbqJmHvgOnTlgxUFhS-L5JK-ZGbPBgMbAJbxIjoc14U41gx8HweiooxRjpNYkw-1cpZIXohA7GIseo7tbY'} 
                          className="w-8 h-8 rounded-full border border-outline-variant object-cover"
                        />
                        <span className="font-semibold text-on-surface">{member.full_name}</span>
                        <span className={`text-[10px] font-bold font-label-caps px-2 py-0.5 rounded-full uppercase ${member.role === 'admin' ? 'bg-red-500/20 text-red-400' : member.role === 'coordinator' ? 'bg-amber-400/20 text-amber-300' : 'bg-primary/20 text-primary'}`}>
                          {member.role}
                        </span>
                      </td>
                      <td className="p-4 text-on-surface-variant text-sm">{member.email}</td>
                      <td className="p-4 text-on-surface-variant text-sm">{member.department || 'N/A'}</td>
                      <td className="p-4 text-center font-mono-data text-sm font-semibold">{member.contributionsCount}</td>
                      {isAdmin && (
                        <td className="p-4 text-right space-x-2" onClick={(e) => e.stopPropagation()}>
                          <button 
                            onClick={() => {
                              setEditForm(member)
                              setShowEditDialog(true)
                            }}
                            className="p-1.5 text-primary hover:bg-primary-container/20 rounded transition-colors"
                          >
                            <span className="material-symbols-outlined text-sm">edit</span>
                          </button>
                          <button 
                            onClick={() => handleDelete(member.id)}
                            className="p-1.5 text-error hover:bg-error/20 rounded transition-colors"
                          >
                            <span className="material-symbols-outlined text-sm">delete</span>
                          </button>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Selected Member Side Panel Drawer */}
        {selectedMember && (
          <div className="lg:col-span-4 bg-surface-container rounded-xl border border-outline-variant p-6 shadow-md animate-in slide-in-from-right duration-200">
            <div className="flex justify-between items-start mb-6">
              <h3 className="font-headline-lg text-headline-lg text-on-surface">Member Details</h3>
              <button 
                onClick={() => setSelectedMember(null)}
                className="p-1 text-on-surface-variant hover:bg-surface-container-high rounded"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>
            
            <div className="flex flex-col items-center text-center pb-6 border-b border-outline-variant mb-6">
              <img 
                alt="" 
                src={selectedMember.avatar_url || 'https://lh3.googleusercontent.com/aida-public/AB6AXuBNaqMiWFAn3N5e7M0gwmYiSokY3sIvWQwnYZMA0OyBqm4ptCO25QtOwdw1OQ5Rt5QTNH1uDqGHdu_L_t9wzqgFCLo5yIV_baf24Wf-xNCZxCaAlPkv5VLrFh3hXAREI068rYzK2DKm2y8Ru5FLCbUMv8cBS3F9GBx18Fv6wZ0tW9z9zXW40sIJ99UJvYbqJmHvgOnTlgxUFhS-L5JK-ZGbPBgMbAJbxIjoc14U41gx8HweiooxRjpNYkw-1cpZIXohA7GIseo7tbY'} 
                className="w-20 h-20 rounded-full border border-outline-variant object-cover mb-4"
              />
              <h4 className="font-headline-lg text-lg text-on-surface">{selectedMember.full_name}</h4>
              <p className="text-sm text-on-surface-variant uppercase font-label-caps tracking-wider mt-1">{selectedMember.role}</p>
              
              <div className="flex gap-4 mt-4">
                {selectedMember.github_url && (
                  <a href={selectedMember.github_url} target="_blank" rel="noreferrer" className="text-on-surface-variant hover:text-primary transition-colors">
                    <span className="material-symbols-outlined">code</span>
                  </a>
                )}
                {selectedMember.linkedin_url && (
                  <a href={selectedMember.linkedin_url} target="_blank" rel="noreferrer" className="text-on-surface-variant hover:text-primary transition-colors">
                    <span className="material-symbols-outlined">account_box</span>
                  </a>
                )}
              </div>
            </div>

            <div className="space-y-4 text-left">
              <div>
                <span className="block text-[10px] font-label-caps text-on-surface-variant uppercase">Academic Details</span>
                <p className="text-sm text-on-surface font-semibold">{selectedMember.department || 'N/A'} • {selectedMember.year || 'N/A'}</p>
              </div>

              {selectedMember.bio && (
                <div>
                  <span className="block text-[10px] font-label-caps text-on-surface-variant uppercase">Bio</span>
                  <p className="text-sm text-on-surface leading-relaxed mt-1">{selectedMember.bio}</p>
                </div>
              )}

              {selectedMember.skills && selectedMember.skills.length > 0 && (
                <div>
                  <span className="block text-[10px] font-label-caps text-on-surface-variant uppercase mb-2">Skills</span>
                  <div className="flex flex-wrap gap-2">
                    {selectedMember.skills.map((skill, index) => (
                      <span key={index} className="text-xs bg-surface-container-high text-on-surface-variant px-2.5 py-1 rounded-full border border-outline-variant font-medium">
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Dialog for Adding Member */}
      {showAddDialog && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-surface border border-outline-variant rounded-xl max-w-md w-full p-6 shadow-xl overflow-y-auto max-h-[90vh]">
            <h3 className="font-headline-lg text-headline-lg text-on-surface mb-4">Add Member Profile</h3>
            <form onSubmit={handleAddSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Full Name</label>
                <input 
                  type="text" 
                  value={newMemberForm.full_name}
                  onChange={(e) => setNewMemberForm({ ...newMemberForm, full_name: e.target.value })}
                  className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary focus:border-primary"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Email</label>
                <input 
                  type="email" 
                  value={newMemberForm.email}
                  onChange={(e) => setNewMemberForm({ ...newMemberForm, email: e.target.value })}
                  className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Department</label>
                  <input 
                    type="text" 
                    value={newMemberForm.department}
                    onChange={(e) => setNewMemberForm({ ...newMemberForm, department: e.target.value })}
                    className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary"
                    placeholder="e.g. Computer Science"
                  />
                </div>
                <div>
                  <label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Academic Year</label>
                  <input 
                    type="text" 
                    value={newMemberForm.year}
                    onChange={(e) => setNewMemberForm({ ...newMemberForm, year: e.target.value })}
                    className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary"
                    placeholder="e.g. 2nd Year"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Role</label>
                <select 
                  value={newMemberForm.role}
                  onChange={(e) => setNewMemberForm({ ...newMemberForm, role: e.target.value })}
                  className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary"
                >
                  <option value="member">Member</option>
                  <option value="coordinator">Coordinator</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Skills (comma separated)</label>
                <input 
                  type="text" 
                  value={newMemberForm.skills}
                  onChange={(e) => setNewMemberForm({ ...newMemberForm, skills: e.target.value })}
                  className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary"
                  placeholder="React, CSS, Python"
                />
              </div>
              <div>
                <label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Bio</label>
                <textarea 
                  value={newMemberForm.bio}
                  onChange={(e) => setNewMemberForm({ ...newMemberForm, bio: e.target.value })}
                  className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm h-20 resize-none focus:ring-primary"
                  placeholder="Tell us about yourself..."
                />
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button 
                  type="button" 
                  onClick={() => setShowAddDialog(false)}
                  className="px-4 py-2 text-on-surface-variant hover:bg-surface-container-high rounded-lg font-label-caps text-xs uppercase"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="px-5 py-2 bg-primary text-on-primary rounded-lg font-bold font-label-caps text-xs uppercase hover:brightness-110"
                >
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Dialog for Editing Member */}
      {showEditDialog && editForm && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-surface border border-outline-variant rounded-xl max-w-md w-full p-6 shadow-xl overflow-y-auto max-h-[90vh]">
            <h3 className="font-headline-lg text-headline-lg text-on-surface mb-4">Edit Member Profile</h3>
            <form onSubmit={handleEditSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Full Name</label>
                <input 
                  type="text" 
                  value={editForm.full_name}
                  onChange={(e) => setEditForm({ ...editForm, full_name: e.target.value })}
                  className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary focus:border-primary"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Email</label>
                <input 
                  type="email" 
                  value={editForm.email}
                  onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                  className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Department</label>
                  <input 
                    type="text" 
                    value={editForm.department || ''}
                    onChange={(e) => setEditForm({ ...editForm, department: e.target.value })}
                    className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary"
                  />
                </div>
                <div>
                  <label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Academic Year</label>
                  <input 
                    type="text" 
                    value={editForm.year || ''}
                    onChange={(e) => setEditForm({ ...editForm, year: e.target.value })}
                    className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Role</label>
                <select 
                  value={editForm.role}
                  onChange={(e) => setEditForm({ ...editForm, role: e.target.value })}
                  className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary"
                >
                  <option value="member">Member</option>
                  <option value="coordinator">Coordinator</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Skills (comma separated)</label>
                <input 
                  type="text" 
                  value={Array.isArray(editForm.skills) ? editForm.skills.join(', ') : editForm.skills || ''}
                  onChange={(e) => setEditForm({ ...editForm, skills: e.target.value })}
                  className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm focus:ring-primary"
                />
              </div>
              <div>
                <label className="block text-xs font-label-caps text-on-surface-variant mb-1 uppercase">Bio</label>
                <textarea 
                  value={editForm.bio || ''}
                  onChange={(e) => setEditForm({ ...editForm, bio: e.target.value })}
                  className="w-full bg-surface-container-low text-on-surface p-3 rounded-lg border border-outline-variant text-sm h-20 resize-none focus:ring-primary"
                />
              </div>
              <div className="flex justify-end gap-3 pt-2">
                <button 
                  type="button" 
                  onClick={() => setShowEditDialog(false)}
                  className="px-4 py-2 text-on-surface-variant hover:bg-surface-container-high rounded-lg font-label-caps text-xs uppercase"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="px-5 py-2 bg-primary text-on-primary rounded-lg font-bold font-label-caps text-xs uppercase hover:brightness-110"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </main>
  )
}

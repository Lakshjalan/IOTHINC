import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth'
import { supabase } from '../supabaseClient'

export const Learn = () => {
  const { role } = useAuth()
  const canManage = role === 'admin'
  const [typeTab, setTypeTab] = useState('All')
  const [resources, setResources] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => { document.title = "IOTHINC - Training & Learning" }, [])

  const fetchResources = async () => {
    setLoading(true)
    let q = supabase.from('learning_resources').select('*, uploader:profiles!learning_resources_uploaded_by_fkey(full_name)').order('created_at', { ascending: false })
    if (typeTab !== 'All') q = q.eq('type', typeTab)
    const { data } = await q
    setResources(data || [])
    setLoading(false)
  }

  useEffect(() => { fetchResources() }, [typeTab])

  const tabs = ['All', 'VIDEO', 'ARTICLE', 'PDF', 'WORKSHOP']
  const typeIcon = (t) => ({ VIDEO: 'play_circle', ARTICLE: 'article', PDF: 'picture_as_pdf', WORKSHOP: 'construction' }[t] || 'school')
  const typeColor = (t) => ({ VIDEO: 'bg-error/20 text-error', ARTICLE: 'bg-primary/20 text-primary', PDF: 'bg-amber-500/20 text-amber-400', WORKSHOP: 'bg-success/20 text-success' }[t] || 'bg-surface-variant text-on-surface-variant')

  return (
    <main className="flex-1 px-4 md:px-stack-lg pt-24 pb-section-gap max-w-7xl mx-auto w-full">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="font-headline-xl text-headline-xl text-on-surface">Training & Learning</h2>
          <p className="font-body-md text-body-md text-on-surface-variant mt-2">Access curated learning resources and tutorials.</p>
        </div>
        {canManage && (
          <Link to="/learn/new" className="flex items-center gap-2 bg-primary text-on-primary font-bold font-label-caps text-xs uppercase px-4 py-3 rounded-lg hover:brightness-110 active:scale-[0.98] transition-all">
            <span className="material-symbols-outlined">add</span>New Resource
          </Link>
        )}
      </div>

      <div className="flex gap-2 border-b border-outline-variant mb-6 pb-px overflow-x-auto no-scrollbar">
        {tabs.map(t => (
          <button key={t} onClick={() => setTypeTab(t)} className={`px-4 py-2.5 font-label-caps text-xs uppercase font-bold border-b-2 transition-all whitespace-nowrap ${typeTab === t ? 'border-primary text-primary' : 'border-transparent text-on-surface-variant hover:text-on-surface'}`}>{t}</button>
        ))}
      </div>

      {loading ? (
        <div className="p-12 text-center"><svg className="animate-spin h-8 w-8 text-primary mx-auto" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" fill="currentColor"/></svg></div>
      ) : resources.length === 0 ? (
        <div className="bg-surface-container rounded-xl border border-outline-variant p-12 text-center text-on-surface-variant italic">No resources found.</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {resources.map(r => (
            <div key={r.id} className="bg-surface-container rounded-xl border border-outline-variant p-5 shadow-sm hover:shadow-md transition-shadow flex flex-col">
              <div className="flex items-center justify-between mb-3">
                <span className={`text-[10px] font-bold font-label-caps uppercase px-2 py-0.5 rounded flex items-center gap-1 ${typeColor(r.type)}`}><span className="material-symbols-outlined text-sm">{typeIcon(r.type)}</span>{r.type}</span>
                {r.track && <span className="text-[10px] text-outline font-label-caps uppercase bg-surface-variant px-2 py-0.5 rounded">{r.track}</span>}
              </div>
              <h3 className="font-bold text-on-surface mb-2 line-clamp-2">{r.title}</h3>
              <p className="text-xs text-on-surface-variant leading-relaxed line-clamp-3 flex-1 mb-4">{r.description}</p>
              <div className="flex items-center justify-between pt-3 border-t border-outline-variant/30">
                <div className="text-[10px] text-outline font-label-caps uppercase">
                  <div>{r.uploader?.full_name || 'Admin'}</div>
                  {r.duration_mins && <div>{r.duration_mins} min</div>}
                </div>
                {r.url && (
                  <a href={r.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-primary text-xs font-bold font-label-caps uppercase hover:underline">
                    <span className="material-symbols-outlined text-sm">open_in_new</span>Open
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </main>
  )
}
